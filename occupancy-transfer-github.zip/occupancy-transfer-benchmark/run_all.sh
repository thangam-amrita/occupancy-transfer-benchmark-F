#!/usr/bin/env bash
# Full pipeline (revision 1). Run ./fetch_data.sh first. About three hours on 2 CPU cores.
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"; S="$ROOT/occ/scripts"; export OMP_NUM_THREADS=1
python3 $S/check_robod_alignment.py "$ROOT"     # lag analysis of the ROBOD release -> occ/res_robod_alignment.csv
python3 $S/harmonise.py "$ROOT"                 # 15-min grid, majority rule, ROBOD corrected -> occ/harmonised15.pkl
python3 $S/harmonise.py "$ROOT" any             # any-occupancy rule                         -> occ/harmonised15_any.pkl
python3 $S/harmonise.py "$ROOT" majority noshift  # ROBOD as released (no time correction)   -> occ/harmonised15_noshift.pkl
python3 $S/build.py "$ROOT"; python3 $S/build.py "$ROOT" _any; python3 $S/build.py "$ROOT" _noshift
python3 $S/exp_main.py "$ROOT"                  # within-dataset, single-source, LODO (optionally split: nolight | light)
python3 $S/exp_thr.py  "$ROOT"                  # operating point, oracle and day-1 thresholds
python3 $S/exp_more.py "$ROOT"                  # label budget
python3 $S/exp_rev.py  "$ROOT"                  # EM/BBSE, sliding-window normalisation, rolling origin, budget weighting
python3 $S/exp_rule.py "$ROOT"                  # labelling-rule sensitivity
python3 $S/exp_em2.py  "$ROOT"                  # EM with calibrated posteriors
python3 $S/exp_tune.py "$ROOT"                  # source-only hyperparameter tuning
python3 $S/exp_base.py "$ROOT"                  # CNN-LSTM, DANN, CORAL, importance weighting
python3 $S/exp_r2.py   "$ROOT"                  # hierarchy (matched volume), commissioning, complete-record LODO, ROBOD correction
python3 $S/sig.py      "$ROOT"                  # day-level and dataset-level paired tests
python3 $S/fig_dist.py "$ROOT"; python3 $S/gen_mdpi.py "$ROOT"   # tables, numbers and figures -> apaper/
