# occupancy-transfer-benchmark

Code and results for the article:

> J. Jesy Janet Kumari and Thangam S, *Can IoT Occupancy Sensor Work in an Unseen Room? A Cross-Dataset Benchmark Using Environmental Sensors*, submitted to *Sensors* (MDPI), 2026.

## Contents

```
data/            UCI-OD and UCI-ROE datasets
occ/raw/         DK-APT dataset
occ/scripts/     analysis code
results/         result tables used in the article
fetch_data.sh    downloads the AAL and ROBOD datasets and checks them
run_all.sh       runs all scripts in order
requirements.txt Python packages
```

## Scripts

| Script | What it does |
|---|---|
| `check_robod_alignment.py` | checks the time alignment of the ROBOD data |
| `harmonise.py` | puts all five datasets on a common 15-min grid |
| `build.py`, `feats.py` | compute the input features |
| `common.py`, `exp_tune_lib.py` | shared models, splits and metrics |
| `exp_main.py` | within-dataset, single-source and leave-one-dataset-out experiments |
| `exp_thr.py` | decision-threshold experiments |
| `exp_more.py` | labeled-day budget |
| `exp_rev.py`, `exp_em2.py` | label-shift correction and normalization |
| `exp_rule.py` | labeling-rule check |
| `exp_tune.py` | hyperparameter tuning |
| `exp_base.py` | CNN-LSTM and domain-adaptation baselines |
| `exp_r2.py` | room/building hierarchy, commissioning, ROBOD correction |
| `sig.py` | significance tests |
| `fig_dist.py`, `gen_mdpi.py` | tables and figures |

## How to run

```bash
pip install -r requirements.txt
./fetch_data.sh
./run_all.sh
```

## Data

| Dataset | Source |
|---|---|
| UCI-OD | https://archive.ics.uci.edu/dataset/357/occupancy+detection |
| UCI-ROE | https://archive.ics.uci.edu/dataset/864/room+occupancy+estimation |
| AAL | https://doi.org/10.5281/zenodo.10673763 |
| ROBOD | https://github.com/ideas-lab-nus/robod |
| DK-APT | https://doi.org/10.5281/zenodo.10761326 |

MD5 checksums of the input files:

```
e9ae415a491d807ccdece8e948458de0  data/occdet/datatest.txt
802204a1a3cc04822f246a77fd9f0c23  data/occdet/datatest2.txt
e656cd731300cb444bd10fcd28071e37  data/occdet/datatraining.txt
f07c72f4d375929c27b141743c41fd46  data/roomocc/Occupancy_Estimation.csv
4b7fd01aa417fb84a6880bb61d94775d  occ/raw/dk_apartments.csv
51b6528edbc2ccd0d78282a2e75668e1  official/aal/dataset__2023_02_27__2023_12_31.csv
c63201fb789381e3485d1c3fda483690  official/robod/combined_Room1.csv
638b80ee99faa7c10fac73d099766496  official/robod/combined_Room2.csv
c3fc17464fd28618dd7e424b96c411f8  official/robod/combined_Room3.csv
f49025e0a01c0ddf0f743c3d30e314af  official/robod/combined_Room4.csv
c58b9fcadaa37f247d8e2091bdadfd1f  official/robod/combined_Room5.csv
```

## License

Code: MIT (`LICENSE`). The datasets remain under their publishers' licenses.

Contact: Thangam S, s_thangam@blr.amrita.edu
