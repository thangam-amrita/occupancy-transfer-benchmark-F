#!/usr/bin/env bash
# Download the two official releases that are not stored in this repository and verify their checksums.
#   AAL   : Melgaard et al. (2024), Zenodo doi:10.5281/zenodo.10673763 (CC BY 4.0), 5-min file, 88 MB
#   ROBOD : Tekler et al. (2022), https://github.com/ideas-lab-nus/robod, commit 6577c3b0 (five rooms)
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"; mkdir -p "$ROOT/official/aal" "$ROOT/official/robod"
curl -L -o "$ROOT/official/aal/dataset__2023_02_27__2023_12_31.csv" \
  "https://zenodo.org/records/10673763/files/dataset__2023_02_27__2023_12_31.csv?download=1"
TMP=$(mktemp -d); git clone -q https://github.com/ideas-lab-nus/robod.git "$TMP/robod"
git -C "$TMP/robod" checkout -q 6577c3b0fe734b6d6977cf23ef3ef8d79850d0c1
cp "$TMP"/robod/Data/combined_Room*.csv "$ROOT/official/robod/"; rm -rf "$TMP"
cd "$ROOT" && md5sum -c <<'SUMS'
51b6528edbc2ccd0d78282a2e75668e1  official/aal/dataset__2023_02_27__2023_12_31.csv
c63201fb789381e3485d1c3fda483690  official/robod/combined_Room1.csv
638b80ee99faa7c10fac73d099766496  official/robod/combined_Room2.csv
c3fc17464fd28618dd7e424b96c411f8  official/robod/combined_Room3.csv
f49025e0a01c0ddf0f743c3d30e314af  official/robod/combined_Room4.csv
c58b9fcadaa37f247d8e2091bdadfd1f  official/robod/combined_Room5.csv
SUMS
