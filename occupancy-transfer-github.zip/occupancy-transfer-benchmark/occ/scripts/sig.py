"""Paired day-block bootstrap tests on the mean-over-targets difference."""
import sys,pickle,numpy as np,pandas as pd; S=sys.argv[1]; sys.path.insert(0,S+'/occ/scripts')
from common import *
from scipy.stats import rankdata
from sklearn.metrics import f1_score
import ast
from exp_tune_lib import fitp
TU=pd.read_csv(S+'/occ/res_tune.csv')
F=pd.read_pickle(S+'/occ/features.pkl').sort_values(['room','ts']).reset_index(drop=True)
P=pickle.load(open(S+'/occ/preds_base.pkl','rb'))
def auc(y,p):
    n1=y.sum(); n0=len(y)-n1; r=rankdata(p); return (r[y==1].sum()-n1*(n1+1)/2)/(n1*n0)
NB=5000; rng=np.random.default_rng(1); out=[]
for light in [False,True]:
    doms=DOMS if not light else [d for d in DOMS if d!='DK-APT']; D=F[F.building.isin(doms)].reset_index(drop=True)
    cols=fsets(light)['ALL']; TE={}; EXTRA={}
    for tgt in doms:
        te=D[(D.building==tgt)&(D.split=='test')]; TE[tgt]=te
        trt=D[(D.building==tgt)&(D.split=='train')]; src=D[(D.building!=tgt)&(D.split=='train')]
        days=sorted(trt.day.unique()); d1=next(d for d in days if trt[trt.day==d].occ.nunique()==2); lab=trt[trt.day==d1]
        for mn in ['LR','HGB']:
            p,m=fit_predict(mn,cols,src,te,0); pl=m.predict_proba(lab[cols].values)[:,1]
            _,t1=best_threshold(lab.occ.values,pl)
            EXTRA[(mn,tgt)]=(p,t1)
            # EM prior correction (unlabelled target training period)
            w=weights(src); pi_s=float((w*src.occ.values).sum()/w.sum()); pu=m.predict_proba(trt[cols].values)[:,1]; pi=pi_s
            for _ in range(200):
                a=pi/pi_s*pu; b=(1-pi)/(1-pi_s)*(1-pu); new=(a/(a+b)).mean()
                if abs(new-pi)<1e-6: break
                pi=new
            pi=float(np.clip(pi,0.01,0.99)); a=pi/pi_s*p; b=(1-pi)/(1-pi_s)*(1-p); EXTRA[(mn+'EM',tgt)]=(a/(a+b),0.5)
        for mn in ['LR','HGB','RF']:
            r=TU[(TU.light==light)&(TU.fs=='ALL')&(TU.model==mn)&(TU.tgt==tgt)].iloc[0]
            P[(light,mn+'-tuned','lodo',tgt,0)]=fitp(mn,ast.literal_eval(r.hp),cols,src,te)
    # ---- day-block resamples per target, stored as day-count vectors (shared by all comparisons -> paired)
    CNT={}; DAYIX={}
    for tgt in doms:
        te=TE[tgt]; ud,di=np.unique(te.day.values,return_inverse=True); y=te.occ.values.astype(int)
        pos_d=np.bincount(di,weights=y,minlength=len(ud)); n_d=np.bincount(di,minlength=len(ud)); L=[]
        while len(L)<NB:
            c=np.bincount(rng.integers(0,len(ud),len(ud)),minlength=len(ud)).astype(float)
            npos=c@pos_d; ntot=c@n_d
            if 0<npos<ntot: L.append(c)
        CNT[tgt]=np.array(L); DAYIX[tgt]=di
    CACHE={}
    def auc_boot(p,tgt):
        """AUROC of score vector p on every day resample (weighted Mann-Whitney, exact ties) + on the observed test set."""
        y=TE[tgt].occ.values.astype(int); di=DAYIX[tgt]; nd=CNT[tgt].shape[1]
        u,g=np.unique(p,return_inverse=True); G=len(u)
        Ap=np.zeros((nd,G)); An=np.zeros((nd,G))
        np.add.at(Ap,(di[y==1],g[y==1]),1.0); np.add.at(An,(di[y==0],g[y==0]),1.0)
        res=[]
        for k in range(0,NB,250):
            C=CNT[tgt][k:k+250]; Wp=C@Ap; Wn=C@An
            cn=np.cumsum(Wn,axis=1)-Wn
            res.append((Wp*(cn+0.5*Wn)).sum(1)/(Wp.sum(1)*Wn.sum(1)))
        Wp=Ap.sum(0); Wn=An.sum(0); cn=np.cumsum(Wn)-Wn; obs=(Wp*(cn+0.5*Wn)).sum()/(Wp.sum()*Wn.sum())
        return obs,np.concatenate(res)
    def f1_boot(yhat,tgt):
        y=TE[tgt].occ.values.astype(int); di=DAYIX[tgt]; nd=CNT[tgt].shape[1]
        tp=np.bincount(di,weights=(y==1)&(yhat==1),minlength=nd); fp=np.bincount(di,weights=(y==0)&(yhat==1),minlength=nd); fn=np.bincount(di,weights=(y==1)&(yhat==0),minlength=nd)
        C=CNT[tgt]; TP=C@tp; FP=C@fp; FN=C@fn; den=2*TP+FP+FN
        b=np.where(den>0,2*TP/np.maximum(den,1e-12),0.0); d0=2*tp.sum()+fp.sum()+fn.sum()
        return (2*tp.sum()/d0 if d0>0 else 0.0), b
    def score(method,setting,tgt):
        key=('auc',method,setting,tgt)
        if key not in CACHE:
            ks=[k for k in P if k[0]==light and k[1]==method and k[2]==setting and k[3]==tgt]
            R_=[auc_boot(P[k],tgt) for k in ks]
            CACHE[key]=(np.mean([r[0] for r in R_]),np.mean([r[1] for r in R_],axis=0))
        return CACHE[key]
    def f1s(mn,tgt,mode):
        key=('f1',mn,tgt,mode)
        if key not in CACHE:
            p,t1=EXTRA[(mn,tgt)]; t=0.5 if mode in('0.5','em') else t1
            CACHE[key]=f1_boot((p>=t).astype(int),tgt)
        return CACHE[key]
    comps=[('AUROC','LR within','LR LODO',lambda t:score('LR','within',t),lambda t:score('LR','lodo',t)),
           ('AUROC','LR LODO','HGB LODO',lambda t:score('LR','lodo',t),lambda t:score('HGB','lodo',t)),
           ('AUROC','LR LODO','CNN-LSTM LODO',lambda t:score('LR','lodo',t),lambda t:score('CNN-LSTM','lodo',t)),
           ('AUROC','CNN-LSTM within','CNN-LSTM LODO',lambda t:score('CNN-LSTM','within',t),lambda t:score('CNN-LSTM','lodo',t)),
           ('AUROC','CNN-LSTM+DANN LODO','CNN-LSTM LODO',lambda t:score('CNN-LSTM+DANN','lodo',t),lambda t:score('CNN-LSTM','lodo',t)),
           ('AUROC','LR+CORAL LODO','LR LODO',lambda t:score('LR+CORAL','lodo',t),lambda t:score('LR','lodo',t)),
           ('AUROC','LR+IW LODO','LR LODO',lambda t:score('LR+IW','lodo',t),lambda t:score('LR','lodo',t)),
           ('AUROC','HGB+CORAL LODO','HGB LODO',lambda t:score('HGB+CORAL','lodo',t),lambda t:score('HGB','lodo',t)),
           ('AUROC','HGB+IW LODO','HGB LODO',lambda t:score('HGB+IW','lodo',t),lambda t:score('HGB','lodo',t)),
           ('AUROC','LR-tuned LODO','HGB-tuned LODO',lambda t:score('LR-tuned','lodo',t),lambda t:score('HGB-tuned','lodo',t)),
           ('AUROC','LR-tuned LODO','RF-tuned LODO',lambda t:score('LR-tuned','lodo',t),lambda t:score('RF-tuned','lodo',t)),
           ('F1','LR LODO EM prior','LR LODO 0.5',lambda t:f1s('LREM',t,'em'),lambda t:f1s('LR',t,'0.5')),
           ('F1','HGB LODO EM prior','HGB LODO 0.5',lambda t:f1s('HGBEM',t,'em'),lambda t:f1s('HGB',t,'0.5')),
           ('F1','LR LODO day-1 thr.','LR LODO 0.5',lambda t:f1s('LR',t,'d1'),lambda t:f1s('LR',t,'0.5')),
           ('F1','HGB LODO day-1 thr.','HGB LODO 0.5',lambda t:f1s('HGB',t,'d1'),lambda t:f1s('HGB',t,'0.5'))]
    import itertools
    hrng=np.random.default_rng(2)
    for met,a,b,fa,fb in comps:
        A_=[fa(t) for t in doms]; B_=[fb(t) for t in doms]
        dt=np.array([x[0]-y[0] for x,y in zip(A_,B_)]); obs=dt.mean()
        per=np.stack([x[1]-y[1] for x,y in zip(A_,B_)],axis=1)   # NB x targets
        bs=per.mean(1)
        p=min(1.0,2*min((bs<=0).mean(),(bs>=0).mean()))
        # dataset-level uncertainty: (i) two-stage bootstrap: targets with replacement, then that target's day resample
        ti=hrng.integers(0,len(doms),size=(NB,len(doms))); hb=per[np.arange(NB)[:,None],ti].mean(1)
        # (ii) exact sign-flip randomisation test over targets (minimum attainable two-sided p = 2/2^n)
        flips=np.array(list(itertools.product([-1,1],repeat=len(doms)))); p_sf=float((np.abs((flips*dt).mean(1))>=abs(obs)-1e-12).mean())
        out.append(dict(light=light,metric=met,A=a,B=b,diff=obs,lo=np.percentile(bs,2.5),hi=np.percentile(bs,97.5),p=p,n_targets=len(doms),
                        n_pos=int((dt>0).sum()),per_target=';'.join(f'{t}:{v:+.3f}' for t,v in zip(doms,dt)),
                        h_lo=np.percentile(hb,2.5),h_hi=np.percentile(hb,97.5),p_signflip=p_sf))
        print(light,a,b,round(obs,3),round(p,4),round(p_sf,4),flush=True)
O=pd.DataFrame(out)
# Holm-Bonferroni correction across all tests
o=O.p.values.argsort(); m=len(O); adj=np.empty(m); run=0
for i,j in enumerate(o): run=max(run,min(1.0,(m-i)*O.p.values[j])); adj[j]=run
O['p_holm']=adj; O.to_csv(S+'/occ/res_sig.csv',index=False); print('done')
