"""Revision experiments: label-shift correction (EM, BBSE), sliding-window normalisation (SWN),
rolling-origin evaluation (AAL, ROBOD), label-rule sensitivity, label-budget weighting."""
import sys,time,numpy as np,pandas as pd; S=sys.argv[1]; sys.path.insert(0,S+'/occ/scripts')
from common import *
from sklearn.metrics import f1_score
F=pd.read_pickle(S+'/occ/features.pkl').reset_index(drop=True)
# ---- sliding-window normalisation (Vanhaeverbeke et al. 2025): z-score with mean/std of the past 30 days (causal)
def add_swn(F):
    F=F.copy()
    for r,g in F.groupby('room'):
        x=g.set_index(pd.DatetimeIndex(g.ts)).sort_index()
        for s in ['T','CO2','Light']:
            m=x[s].rolling('30D',min_periods=24).mean(); sd=x[s].rolling('30D',min_periods=24).std()
            F.loc[g.sort_values('ts').index,'sw_'+s]=((x[s]-m)/sd.replace(0,np.nan)).values
    return F
F=add_swn(F)
def swn_cols(light): 
    c=['sw_T','sw_CO2']+(['sw_Light'] if light else []); return c, c+['hsin','hcos']+[x for x in fsets(light)['DYN']]
R=[]; t0=time.time()
def em_prior(p,pi_s,iters=200):
    pi=pi_s
    for _ in range(iters):
        a=pi/pi_s*p; b=(1-pi)/(1-pi_s)*(1-p); q=a/(a+b); new=q.mean()
        if abs(new-pi)<1e-6: break
        pi=new
    return float(np.clip(pi,0.01,0.99))
def adjust(p,pi_s,pi_t):
    a=pi_t/pi_s*p; b=(1-pi_t)/(1-pi_s)*(1-p); return a/(a+b)
for light in [False,True]:
    doms=DOMS if not light else [d for d in DOMS if d!='DK-APT']; D=F[F.building.isin(doms)]; trA=D[D.split=='train']
    FS=dict(fsets(light)); sw,swd=swn_cols(light); FS['SWN']=sw+['hsin','hcos']; FS['SWN+DYN']=swd
    for fs in ['ALL','SWN','SWN+DYN']:
        cols=FS[fs]
        for mn in ['LR','HGB']:
            for tgt in doms:
                te=D[(D.building==tgt)&(D.split=='test')]; tu=D[(D.building==tgt)&(D.split=='train')]; src=trA[trA.building!=tgt]
                y=te.occ.values.astype(int)
                if fs!='ALL':
                    for setting,tr in [('within',tu),('lodo',src)]:
                        p,_=fit_predict(mn,cols,tr,te,0); R.append(dict(exp='swn',light=light,fs=fs,model=mn,tgt=tgt,setting=setting,**metrics(y,p)))
                    continue
                p,m=fit_predict(mn,cols,src,te,0); w=weights(src); pi_s=float((w*src.occ.values).sum()/w.sum())
                pu=m.predict_proba(tu[cols].values)[:,1]
                # EM prior estimate from unlabelled target training period
                pi_em=em_prior(pu,pi_s)
                # BBSE: confusion matrix from leave-one-source-out predictions
                C=np.zeros((2,2)); 
                for v in [d for d in doms if d!=tgt]:
                    tr=src[src.building!=v]; va=src[src.building==v]
                    pv,_=fit_predict(mn,cols,tr,va,0); yh=(pv>=0.5).astype(int); wv=np.full(len(va),1.0/len(va))
                    for a in [0,1]:
                        for b in [0,1]: C[a,b]+=wv[(yh==a)&(va.occ.values==b)].sum()/ (len(doms)-1)
                mu=np.array([(pu<0.5).mean(),(pu>=0.5).mean()])
                try:
                    wts=np.linalg.solve(C,mu); ps=np.array([C[:,0].sum(),C[:,1].sum()]); q=np.clip(wts,0,None)*ps; pi_bb=float(np.clip(q[1]/q.sum(),0.01,0.99))
                except Exception: pi_bb=np.nan
                res=dict(exp='labelshift',light=light,fs=fs,model=mn,tgt=tgt,setting='lodo',prev_test=y.mean(),prev_train=tu.occ.mean(),pi_s=pi_s,pi_em=pi_em,pi_bbse=pi_bb,
                         auc=roc_auc_score(y,p),f1_05=f1_score(y,(p>=.5).astype(int)),
                         f1_em=f1_score(y,(adjust(p,pi_s,pi_em)>=.5).astype(int)),
                         f1_bbse=f1_score(y,(adjust(p,pi_s,pi_bb)>=.5).astype(int)) if pi_bb==pi_bb else np.nan)
                R.append(res)
            print(light,fs,mn,round(time.time()-t0),flush=True)
    pd.DataFrame(R).to_csv(S+'/occ/res_rev.csv',index=False)
# ---- rolling-origin evaluation for the two long datasets
for light in [False,True]:
    doms=DOMS if not light else [d for d in DOMS if d!='DK-APT']; D=F[F.building.isin(doms)]; cols=fsets(light)['ALL']
    for tgt in ['AAL','ROBOD']:
        G=D[D.building==tgt]
        for o in [0.5,0.6,0.7,0.8]:
            tr_t=[]; te_t=[]
            for r,g in G.groupby('room'):
                a=g.ts.quantile(o); b=g.ts.quantile(min(o+0.1,1.0))
                tr_t.append(g[g.ts<=a]); te_t.append(g[(g.ts>a)&(g.ts<=b)])
            trt=pd.concat(tr_t); te=pd.concat(te_t); src=D[(D.building!=tgt)&(D.split=='train')]
            if te.occ.nunique()<2: continue
            for mn in ['LR','HGB']:
                for setting,tr in [('within',trt),('lodo',src)]:
                    p,_=fit_predict(mn,cols,tr,te,0)
                    R.append(dict(exp='rolling',light=light,fs='ALL',model=mn,tgt=tgt,origin=o,setting=setting,**metrics(te.occ.values,p)))
    print('rolling',light,round(time.time()-t0),flush=True)
pd.DataFrame(R).to_csv(S+'/occ/res_rev.csv',index=False)
# ---- label budget with target up-weighting (target days get 50% of total weight)
cols=fsets(False)['ALL']; D=F
for mn in ['LR','HGB']:
    for tgt in DOMS:
        te=D[(D.building==tgt)&(D.split=='test')]; trt=D[(D.building==tgt)&(D.split=='train')]; days=sorted(trt.day.unique()); src=D[(D.building!=tgt)&(D.split=='train')]
        for k in [1,2,3]:
            lab=trt[trt.day.isin(days[:k])]
            if lab.occ.nunique()<2: continue
            pool=pd.concat([src,lab]); w=weights(pool); isT=(pool.building==tgt).values
            for share in [0.2,0.5,0.8]:
                tot=w.sum(); ww=w.copy(); ww[isT]=w[isT]/w[isT].sum()*share*tot; ww[~isT]=w[~isT]/w[~isT].sum()*(1-share)*tot
                m=model(mn,0,len(pool)); kw={'logisticregression__sample_weight':ww} if mn=='LR' else {'sample_weight':ww}
                m.fit(pool[cols].values,pool.occ.values.astype(int),**kw); p=m.predict_proba(te[cols].values)[:,1]
                R.append(dict(exp='budget_w',light=False,fs='ALL',model=mn,tgt=tgt,k=k,share=share,**metrics(te.occ.values,p)))
print('budget',round(time.time()-t0),flush=True)
pd.DataFrame(R).to_csv(S+'/occ/res_rev.csv',index=False); print('done')
