import sys,json,time,numpy as np,pandas as pd; S=sys.argv[1]; sys.path.insert(0,S+'/occ/scripts')
from common import *
F=pd.read_pickle(S+'/occ/features.pkl').reset_index(drop=True)
R=[]; t0=time.time()
SEEDS={'LR':[0],'RF':[0,1,2],'HGB':[0,1,2]}
PART=sys.argv[2] if len(sys.argv)>2 else 'both'
for light in [l for l in [False,True] if PART=='both' or (PART=='light')==l]:
    doms=DOMS if not light else [d for d in DOMS if d!='DK-APT']
    D=F[F.building.isin(doms)]
    for fs,cols in fsets(light).items():
        for mn in ['LR','RF','HGB']:
            for seed in SEEDS[mn]:
                tr_all=D[D.split=='train']
                for tgt in doms:
                    te=D[(D.building==tgt)&(D.split=='test')]
                    # within-domain
                    p,_=fit_predict(mn,cols,tr_all[tr_all.building==tgt],te,seed)
                    R.append(dict(light=light,fs=fs,model=mn,seed=seed,setting='within',src=tgt,tgt=tgt,**metrics(te.occ.values,p)))
                    # leave-one-domain-out
                    p,_=fit_predict(mn,cols,tr_all[tr_all.building!=tgt],te,seed)
                    R.append(dict(light=light,fs=fs,model=mn,seed=seed,setting='lodo',src='others',tgt=tgt,**metrics(te.occ.values,p)))
                    # single-source transfer (HGB + LR only, seed 0, to keep run time down)
                    if seed==0 and mn in('HGB','LR'):
                        for src in doms:
                            if src==tgt: continue
                            p,_=fit_predict(mn,cols,tr_all[tr_all.building==src],te,seed)
                            R.append(dict(light=light,fs=fs,model=mn,seed=seed,setting='pair',src=src,tgt=tgt,**metrics(te.occ.values,p)))
        print(light,fs,round(time.time()-t0),flush=True)
pd.DataFrame(R).to_csv(S+'/occ/res_main.csv' if PART=='both' else S+f'/occ/res_main_{PART}.csv',index=False); print('done',len(R))
