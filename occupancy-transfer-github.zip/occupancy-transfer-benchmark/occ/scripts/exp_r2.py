"""Experiments added in revision 1 (reviewer requests). usage: python3 exp_r2.py ROOT [part ...]
parts: hier   room / building / dataset hierarchy, full and matched training volume
       commis commissioning: threshold from the labelled day immediately before each test period
              (standard split for all targets, rolling origins for AAL and ROBOD) and daily recalibration
       full   LODO scored on the complete target record (all days), per dataset and per room
       shift  effect of the ROBOD time-stamp correction
Writes occ/res_r2_<part>.csv"""
import sys, time, zlib, numpy as np, pandas as pd
S = sys.argv[1]; sys.path.insert(0, S + '/occ/scripts')
from common import *
PARTS = sys.argv[2:] or ['hier', 'commis', 'full', 'shift']
F = pd.read_pickle(S + '/occ/features.pkl').reset_index(drop=True)
t0 = time.time()


def log(*a): print(*a, round(time.time() - t0), flush=True)


def apt(room): return room.split('-')[1] if room.startswith('APT') else None


# ------------------------------------------------------------------ hierarchy
if 'hier' in PARTS:
    R = []; cols = fsets(False)['ALL']; tr = F[F.split == 'train']; NREP = 5
    for mn in ['LR', 'HGB']:
        for b in ['AAL', 'ROBOD', 'DK-APT']:
            for r in sorted(F[F.building == b].room.unique()):
                te = F[(F.room == r) & (F.split == 'test')]
                if te.occ.nunique() < 2: continue
                L = [('same room', tr[tr.room == r])]
                if b == 'DK-APT':
                    L += [('other rooms, same building', tr[(tr.room != r) & (tr.room.map(apt) == apt(r))]),
                          ('other buildings, same dataset', tr[(tr.building == b) & (tr.room.map(apt) != apt(r))])]
                else:
                    L += [('other rooms, same building', tr[(tr.building == b) & (tr.room != r)])]
                L += [('other datasets', tr[tr.building != b])]
                if any(d.occ.nunique() < 2 for _, d in L): continue
                N = min(len(d) for _, d in L)
                for lvl, d in L:
                    p, _ = fit_predict(mn, cols, d, te, 0)
                    R.append(dict(model=mn, building=b, room=r, level=lvl, volume='full', ntrain=len(d), rep=0, **metrics(te.occ.values, p)))
                    rng = np.random.default_rng(zlib.crc32(f'{r}|{lvl}'.encode()))
                    for k in range(NREP):
                        for _ in range(50):
                            sub = d.iloc[np.sort(rng.choice(len(d), N, replace=False))]
                            if sub.occ.nunique() == 2: break
                        p, _ = fit_predict(mn, cols, sub, te, 0)
                        R.append(dict(model=mn, building=b, room=r, level=lvl, volume='matched', ntrain=N, rep=k, **metrics(te.occ.values, p)))
            log('hier', mn, b)
    pd.DataFrame(R).to_csv(S + '/occ/res_r2_hier.csv', index=False)

# ------------------------------------------------------------------ commissioning
if 'commis' in PARTS:
    R = []; DAILY = []

    def prev_day_thr(lab_rows, p_lab, days_before, max_back=7):
        """F1-optimal threshold on the most recent day (<= max_back days back) that has both classes."""
        for back, d in enumerate(days_before[::-1][:max_back]):
            m = lab_rows.day.values == d
            if m.sum() and len(np.unique(lab_rows.occ.values[m])) == 2:
                return best_threshold(lab_rows.occ.values[m], p_lab[m])[1], back + 1
        return 0.5, 0

    for light in [False, True]:
        doms = DOMS if not light else [d for d in DOMS if d != 'DK-APT']; D = F[F.building.isin(doms)]; cols = fsets(light)['ALL']
        for tgt in doms:
            G = D[D.building == tgt]; src = D[(D.building != tgt) & (D.split == 'train')]
            origins = [None] + ([0.5, 0.6, 0.7, 0.8] if tgt in ('AAL', 'ROBOD') else [])
            for mn in ['LR', 'HGB']:
                _, m = fit_predict(mn, cols, src, G.iloc[:5], 0)
                pG = m.predict_proba(G[cols].values)[:, 1]; G = G.assign(p=pG)
                for o in origins:
                    te_parts, ys, yh = [], {}, {}
                    for mode in ['0.5', 'pre-day', 'daily', 'oracle']: ys[mode] = []; yh[mode] = []
                    fb = 0; ndays = 0
                    for r, g in G.groupby('room'):
                        g = g.sort_values('ts')
                        if o is None: te = g[g.split == 'test']; before = g[g.split == 'train']
                        else:
                            a = g.ts.quantile(o); b = g.ts.quantile(min(o + 0.1, 1.0)); te = g[(g.ts > a) & (g.ts <= b)]; before = g[g.ts <= a]
                        if len(te) == 0: continue
                        bdays = sorted(before.day.unique())
                        # (i) one labelled day immediately before the test period, threshold kept for the whole period
                        t_pre, back = prev_day_thr(before, before.p.values, bdays); fb += back == 0
                        # (ii) daily: each test day uses the labelled day(s) immediately before it
                        allg = g[g.ts <= te.ts.max()]
                        t_daily = np.empty(len(te))
                        for d in te.day.unique():
                            past = allg[allg.day < d]; t, _ = prev_day_thr(past, past.p.values, sorted(past.day.unique()))
                            t_daily[(te.day == d).values] = t; ndays += 1
                        y = te.occ.values.astype(int); p = te.p.values
                        for mode, thr in [('0.5', 0.5), ('pre-day', t_pre), ('daily', t_daily)]:
                            ys[mode].append(y); yh[mode].append((p >= thr).astype(int))
                        te_parts.append(te)
                    TE = pd.concat(te_parts); y = TE.occ.values.astype(int)
                    if len(np.unique(y)) < 2: continue
                    res = dict(light=light, fs='ALL', model=mn, tgt=tgt, origin='standard' if o is None else o, n=len(y), prev=y.mean(),
                               test_days=TE.day.nunique(), rooms_without_labelled_day=fb, auc=roc_auc_score(y, TE.p.values))
                    for mode in ['0.5', 'pre-day', 'daily']:
                        res['f1_' + mode] = f1_score(np.concatenate(ys[mode]), np.concatenate(yh[mode]), zero_division=0)
                    res['f1_oracle'] = best_threshold(y, TE.p.values)[0]
                    R.append(res)
            log('commis', light, tgt)
    pd.DataFrame(R).to_csv(S + '/occ/res_r2_commis.csv', index=False)

# ------------------------------------------------------------------ LODO on the full target record
if 'full' in PARTS:
    R = []; rng = np.random.default_rng(0)

    def boot(df, p, nb=1000):
        days = df.day.values; ud = np.unique(days); idx = {d: np.where(days == d)[0] for d in ud}; y = df.occ.values.astype(int); out = []
        while len(out) < nb:
            s = np.concatenate([idx[d] for d in rng.choice(ud, len(ud))])
            if 0 < y[s].sum() < len(s): out.append((roc_auc_score(y[s], p[s]), f1_score(y[s], (p[s] >= .5).astype(int), zero_division=0)))
        return np.percentile(np.array(out), [2.5, 97.5], axis=0)
    for light in [False, True]:
        doms = DOMS if not light else [d for d in DOMS if d != 'DK-APT']; D = F[F.building.isin(doms)]; cols = fsets(light)['ALL']
        for mn in ['LR', 'HGB']:
            for tgt in doms:
                G = D[D.building == tgt]; src = D[(D.building != tgt) & (D.split == 'train')]
                p, _ = fit_predict(mn, cols, src, G, 0); G = G.assign(p=p)
                for scope, sub in [('test split', G[G.split == 'test']), ('full record', G)]:
                    y = sub.occ.values.astype(int); lo, hi = boot(sub, sub.p.values)
                    R.append(dict(light=light, model=mn, tgt=tgt, scope=scope, level='dataset', room='all', days=sub.day.nunique(),
                                  auc_lo=lo[0], auc_hi=hi[0], f1_lo=lo[1], f1_hi=hi[1], **metrics(y, sub.p.values)))
                for r, g in G.groupby('room'):
                    if g.occ.nunique() == 2:
                        R.append(dict(light=light, model=mn, tgt=tgt, scope='full record', level='room', room=r, days=g.day.nunique(), **metrics(g.occ.values, g.p.values)))
            log('full', light, mn)
    pd.DataFrame(R).to_csv(S + '/occ/res_r2_full.csv', index=False)

# ------------------------------------------------------------------ ROBOD time-stamp correction
if 'shift' in PARTS:
    R = []
    for ver, f in [('corrected', 'features.pkl'), ('as released', 'features_noshift.pkl')]:
        FF = pd.read_pickle(S + '/occ/' + f).reset_index(drop=True)
        for light in [False, True]:
            doms = DOMS if not light else [d for d in DOMS if d != 'DK-APT']; D = FF[FF.building.isin(doms)]; tr = D[D.split == 'train']
            for fs in ['RAW', 'ALL']:
                cols = fsets(light)[fs]
                for mn in ['LR', 'HGB']:
                    for tgt in doms:
                        te = D[(D.building == tgt) & (D.split == 'test')]
                        for setting, trd in [('within', tr[tr.building == tgt]), ('lodo', tr[tr.building != tgt])]:
                            p, _ = fit_predict(mn, cols, trd, te, 0)
                            R.append(dict(version=ver, light=light, fs=fs, model=mn, tgt=tgt, setting=setting, **metrics(te.occ.values, p)))
        log('shift', ver)
    pd.DataFrame(R).to_csv(S + '/occ/res_r2_shift.csv', index=False)
print('done', PARTS)
