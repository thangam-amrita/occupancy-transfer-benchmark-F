import sys,numpy as np,pandas as pd; S=sys.argv[1]; sys.path.insert(0,S+'/occ/scripts')
from common import *
R=[]
for rule,f in [('majority','features.pkl'),('any','features_any.pkl')]:
    F=pd.read_pickle(S+'/occ/'+f).reset_index(drop=True)
    for light in [False,True]:
        doms=DOMS if not light else [d for d in DOMS if d!='DK-APT']; D=F[F.building.isin(doms)]; cols=fsets(light)['ALL']; tr=D[D.split=='train']
        for mn in ['LR','HGB']:
            for tgt in doms:
                te=D[(D.building==tgt)&(D.split=='test')]
                for setting,trd in [('within',tr[tr.building==tgt]),('lodo',tr[tr.building!=tgt])]:
                    p,_=fit_predict(mn,cols,trd,te,0); R.append(dict(rule=rule,light=light,model=mn,tgt=tgt,setting=setting,**metrics(te.occ.values,p)))
pd.DataFrame(R).to_csv(S+'/occ/res_rule.csv',index=False); print('done')
