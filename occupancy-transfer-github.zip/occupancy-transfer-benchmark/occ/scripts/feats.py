import pandas as pd, numpy as np
SENS=['T','CO2','Light']
def room_feats(g):
    g=g.sort_values('ts').copy(); idx=pd.DatetimeIndex(g.ts); x=g.set_index(idx)
    prev=x.index.to_series().diff()==pd.Timedelta('15min')
    for s in SENS:
        v=x[s]
        x[f'd_{s}']=v.diff().where(prev)                                # 15-min change
        x[f'h1_{s}']=v-v.rolling('60min',min_periods=2).mean()          # deviation from last hour
        base=v.rolling('24h',min_periods=8).quantile(0.05) if s!='T' else v.rolling('24h',min_periods=8).median()
        x[f'rel_{s}']=v-base                                            # relative to own 24 h baseline
    h=x.index.hour+x.index.minute/60
    x['hsin']=np.sin(2*np.pi*h/24); x['hcos']=np.cos(2*np.pi*h/24); x['wkend']=(x.index.weekday>=5).astype(float)
    return x.reset_index(drop=True)
def build(H):
    F=pd.concat([room_feats(g) for _,g in H.groupby('room')],ignore_index=True)
    # chronological 70/30 split per room
    F['split']='train'
    for r,g in F.groupby('room'):
        cut=g.ts.quantile(0.7); F.loc[g.index[g.ts>cut],'split']='test'
    F['day']=F.ts.dt.date.astype(str)
    return F
def zfit(F, cols):
    """per-room z-score using that room's TRAIN-period (unlabelled) statistics"""
    out=F.copy()
    for r,g in F.groupby('room'):
        tr=g[g.split=='train']
        for c in cols:
            mu=tr[c].mean(); sd=tr[c].std()
            out.loc[g.index,'z_'+c]=(g[c]-mu)/(sd if sd and sd>1e-9 else 1.0)
    return out
