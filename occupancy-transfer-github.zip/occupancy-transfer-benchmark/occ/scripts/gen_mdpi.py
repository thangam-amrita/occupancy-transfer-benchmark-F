"""Tables, numbers and figures for the revised Sensors manuscript (revision 1).
usage: python3 gen_mdpi.py ROOT   -> apaper/mdpi_numbers.json, apaper/fig/*.png"""
import sys, os, json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
S = sys.argv[1]; O = S + '/apaper'; os.makedirs(O + '/fig', exist_ok=True)
plt.rcParams.update({'font.family': 'serif', 'font.size': 7.5, 'axes.linewidth': 0.6, 'pdf.fonttype': 42})
rd = lambda f: pd.read_csv(f'{S}/occ/{f}')
F = pd.read_pickle(S + '/occ/features.pkl')
M = rd('res_main.csv'); T = rd('res_thr.csv'); H = rd('res_more.csv'); TU = rd('res_tune.csv'); B = rd('res_base.csv')
RV = rd('res_rev.csv'); RU = rd('res_rule.csv'); E2 = rd('res_em2.csv')
G = rd('res_sig.csv') if os.path.exists(f'{S}/occ/res_sig.csv') else None
HI = rd('res_r2_hier.csv'); CM = rd('res_r2_commis.csv'); FU = rd('res_r2_full.csv'); SH = rd('res_r2_shift.csv')
ORDER = ['UCI-OD', 'UCI-ROE', 'AAL', 'ROBOD', 'DK-APT']; FSO = ['RAW', 'RAW+TIME', 'DYN', 'REL', 'ZNORM', 'INV', 'ALL']
J = {'tables': {}, 'n': {}}
def n(k, v): J['n'][k] = v
f3 = lambda v: f'{v:.3f}'; f2 = lambda v: f'{v:.2f}'
def pf(p): return '<0.001' if p < 0.001 else f'{p:.3f}'
def mm(df, cols=('auc', 'f1')): return df.groupby('tgt')[list(cols)].mean().mean()

# ---------------------------------------------------------------- Table 2 datasets
meta = {'UCI-OD': ('BE', 'office', '1 min', 'photographs'), 'UCI-ROE': ('IN', 'office room', '30 s', 'manual count'),
        'AAL': ('DK', 'offices', '5 min', 'camera + YOLOv5'), 'ROBOD': ('SG', 'lecture, office, library', '5 min', 'presence label'),
        'DK-APT': ('DK', 'residential', '15 min', 'occupant logbook')}
rows = []
for b in ORDER:
    g = F[F.building == b]; te = g[g.split == 'test']; c, ty, res, lab = meta[b]
    rows.append([b, c, ty, str(g.room.nunique()), f'{g.ts.min():%m/%y}–{g.ts.max():%m/%y}', res, lab, f'{len(g):,}', f'{100*g.occ.mean():.1f}',
                 f'{len(te):,} ({int(te.occ.sum()):,})', f'{100*te.occ.mean():.1f}', str(g.day.nunique()), str(te.day.nunique())])
    n(f'rows_{b}', f'{len(g):,}'); n(f'days_{b}', int(g.day.nunique())); n(f'testdays_{b}', int(te.day.nunique()))
    n(f'test_{b}', f'{len(te):,}'); n(f'testocc_{b}', int(te.occ.sum())); n(f'testprev_{b}', f'{100*te.occ.mean():.0f}')
te = F[F.split == 'test']
rows.append(['Total', '', '', str(F.room.nunique()), '', '', '', f'{len(F):,}', f'{100*F.occ.mean():.1f}', f'{len(te):,}', f'{100*te.occ.mean():.1f}', '', ''])
J['tables']['t2'] = rows; n('rooms', int(F.room.nunique())); n('intervals', f'{len(F):,}')
n('robod_rooms', {r: int((F.room == r).sum()) for r in sorted(F[F.building == 'ROBOD'].room.unique())})
med = F.groupby(['building', 'occ'])[['CO2', 'Light']].median()
n('medians', {f'{b}_{int(o)}': [round(float(v.CO2)), (None if np.isnan(v.Light) else round(float(v.Light)))] for (b, o), v in med.iterrows()})

# ---------------------------------------------------------------- Tables 3 and 4 (means over targets)
def agg(light):
    r = M[(M.light == light) & (M.setting.isin(['within', 'lodo']))]
    return r.groupby(['fs', 'model', 'setting', 'tgt'])[['auc', 'f1', 'mcc']].mean().groupby(['fs', 'model', 'setting']).mean().unstack('setting')
for light, key in [(False, 't3'), (True, 't4')]:
    a = agg(light); rows = []; best = a[('auc', 'lodo')].max(); bold = []
    for fs in FSO:
        for i, m in enumerate(['LR', 'RF', 'HGB']):
            x = a.loc[(fs, m)]
            if abs(x[('auc', 'lodo')] - best) < 5e-4: bold.append((len(rows), 3))
            rows.append([fs if i == 0 else '', m, f3(x[('auc', 'within')]), f3(x[('auc', 'lodo')]), f"{x[('auc', 'lodo')]-x[('auc', 'within')]:+.3f}".replace('-', '−'),
                         f3(x[('f1', 'within')]), f3(x[('f1', 'lodo')]), f3(x[('mcc', 'lodo')])])
            for s in ['within', 'lodo']:
                n(f"{'L' if light else ''}{fs}_{m}_{s}_auc", f3(x[('auc', s)])); n(f"{'L' if light else ''}{fs}_{m}_{s}_f1", f3(x[('f1', s)]))
    J['tables'][key] = rows; J['tables'][key + '_bold'] = bold
    d = (a[('auc', 'within')] - a[('auc', 'lodo')])
    for fam, ms in [('LR', ['LR']), ('trees', ['RF', 'HGB'])]:
        v = d[[ix for ix in d.index if ix[1] in ms]]
        n(f"{'L' if light else ''}drop_{fam}", [f3(v.min()), f3(v.max())])
    n(f"{'L' if light else ''}best_lodo", f3(best))
    n(f"{'L' if light else ''}best_lodo_cfg", list(a[('auc', 'lodo')].idxmax()))
    n(f"{'L' if light else ''}ALL_within_range", [f3(a.loc['ALL'][('auc', 'within')].min()), f3(a.loc['ALL'][('auc', 'within')].max())])
    n(f"{'L' if light else ''}ALL_lodo_range", [f3(a.loc['ALL'][('auc', 'lodo')].min()), f3(a.loc['ALL'][('auc', 'lodo')].max())])
    n(f"{'L' if light else ''}ALL_f1w_range", [f3(a.loc['ALL'][('f1', 'within')].min()), f3(a.loc['ALL'][('f1', 'within')].max())])
    n(f"{'L' if light else ''}ALL_f1l_range", [f3(a.loc['ALL'][('f1', 'lodo')].min()), f3(a.loc['ALL'][('f1', 'lodo')].max())])
# illuminance effect on LODO, same four targets
a0 = M[(~M.light) & (M.setting == 'lodo') & (M.tgt != 'DK-APT')].groupby(['fs', 'model', 'tgt']).auc.mean().groupby(['fs', 'model']).mean()
a1 = M[(M.light) & (M.setting == 'lodo')].groupby(['fs', 'model', 'tgt']).auc.mean().groupby(['fs', 'model']).mean()
n('light_lowers_lodo', int((a1 < a0 - 1e-9).sum())); n('light_n', int(len(a1)))
n('light_lodo_delta_range', [f3((a1 - a0).min()), f3((a1 - a0).max())])
w0 = M[(~M.light) & (M.setting == 'within') & (M.tgt != 'DK-APT')].groupby(['fs', 'model', 'tgt']).auc.mean().groupby(['fs', 'model']).mean()
w1 = M[(M.light) & (M.setting == 'within')].groupby(['fs', 'model', 'tgt']).auc.mean().groupby(['fs', 'model']).mean()
n('light_within_delta_range', [f3((w1 - w0).min()), f3((w1 - w0).max())])
n('nolight4_ALL', {m: [f3(w0[('ALL', m)]), f3(a0[('ALL', m)])] for m in ['LR', 'RF', 'HGB']})

# ---------------------------------------------------------------- Table 5 per target with CIs (+ full-record LODO)
rows = []
for m in ['LR', 'HGB']:
    for t in ORDER:
        r = T[(~T.light) & (T.fs == 'ALL') & (T.model == m) & (T.tgt == t)]
        w = r[r.setting == 'within'].iloc[0]; l = r[r.setting == 'lodo'].iloc[0]
        fr = FU[(~FU.light) & (FU.model == m) & (FU.tgt == t) & (FU.scope == 'full record') & (FU.level == 'dataset')].iloc[0]
        rows.append([m if t == ORDER[0] else '', t, f'{100*w.prev:.0f}', f'{w.auc:.3f} [{w.auc_lo:.2f}, {w.auc_hi:.2f}]', f'{l.auc:.3f} [{l.auc_lo:.2f}, {l.auc_hi:.2f}]',
                     f'{fr.auc:.3f} [{fr.auc_lo:.2f}, {fr.auc_hi:.2f}]', f'{w.f1_05:.3f} [{w.f1_lo:.2f}, {w.f1_hi:.2f}]', f'{l.f1_05:.3f} [{l.f1_lo:.2f}, {l.f1_hi:.2f}]'])
        n(f't5_{m}_{t}', dict(w=f3(w.auc), l=f3(l.auc), full=f3(fr.auc), wf=f3(w.f1_05), lf=f3(l.f1_05), lci=[f2(l.auc_lo), f2(l.auc_hi)], fci=[f2(fr.auc_lo), f2(fr.auc_hi)], days=int(fr.days)))
J['tables']['t5'] = rows
# full record summary
fr = FU[(FU.level == 'dataset')].pivot_table(index=['light', 'model', 'tgt'], columns='scope', values='auc')
for (l, m), g in fr.groupby(level=[0, 1]):
    n(f"full_mean_{'L' if l else ''}{m}", [f3(g['test split'].mean()), f3(g['full record'].mean())])
fw = FU[(FU.level == 'dataset')].copy(); fw['w'] = fw.auc_hi - fw.auc_lo
n('ci_width', {f"{t}": [f2(fw[(fw.tgt == t) & (fw.scope == 'test split')].w.median()), f2(fw[(fw.tgt == t) & (fw.scope == 'full record')].w.median())] for t in ORDER})
rr = FU[(FU.level == 'room') & (~FU.light) & (FU.model == 'LR')]
n('room_lodo_LR', {b: [f2(g.auc.min()), f2(g.auc.median()), f2(g.auc.max()), int(len(g))] for b, g in rr.groupby('tgt')})
rmac = rr.groupby('tgt').auc.mean().mean(); rmic = rr.auc.mean(); n('room_vs_dataset_macro', [f3(rr.auc.mean()), f3(rmac)])

# ---------------------------------------------------------------- Table 6 rolling origin
RO = RV[RV.exp == 'rolling']; rows = []; gaps = []
for light in [False, True]:
    for t in ['AAL', 'ROBOD']:
        for m in ['LR', 'HGB']:
            g = RO[(RO.light == light) & (RO.tgt == t) & (RO.model == m)]
            w = g[g.setting == 'within'].auc; o = g[g.setting == 'lodo'].auc
            rows.append(['with L' if light else 'no L', t, m, f'{w.mean():.3f} [{w.min():.2f}, {w.max():.2f}]', f'{o.mean():.3f} [{o.min():.2f}, {o.max():.2f}]'])
            for o_, h in g.groupby('origin'): gaps.append(h[h.setting == 'within'].auc.mean() - h[h.setting == 'lodo'].auc.mean())
J['tables']['t6'] = rows; n('roll_gap', [f3(min(gaps)), f3(max(gaps)), int(sum(x > 0 for x in gaps)), len(gaps)])

# ---------------------------------------------------------------- Table 7 remedies
items = [('LR, within (reference)', lambda l: mm(M[(M.light == l) & (M.fs == 'ALL') & (M.model == 'LR') & (M.setting == 'within')])),
         ('LR, fixed', lambda l: mm(M[(M.light == l) & (M.fs == 'ALL') & (M.model == 'LR') & (M.setting == 'lodo')])),
         ('LR, tuned', lambda l: mm(TU[(TU.light == l) & (TU.fs == 'ALL') & (TU.model == 'LR')])),
         ('HGB, fixed', lambda l: mm(M[(M.light == l) & (M.fs == 'ALL') & (M.model == 'HGB') & (M.setting == 'lodo')])),
         ('HGB, tuned', lambda l: mm(TU[(TU.light == l) & (TU.fs == 'ALL') & (TU.model == 'HGB')])),
         ('RF, fixed', lambda l: mm(M[(M.light == l) & (M.fs == 'ALL') & (M.model == 'RF') & (M.setting == 'lodo')])),
         ('RF, tuned', lambda l: mm(TU[(TU.light == l) & (TU.fs == 'ALL') & (TU.model == 'RF')])),
         ('CNN-LSTM', lambda l: mm(B[(B.light == l) & (B.method == 'CNN-LSTM') & (B.setting == 'lodo')])),
         ('CNN-LSTM + DANN', lambda l: mm(B[(B.light == l) & (B.method == 'CNN-LSTM+DANN')])),
         ('LR + CORAL', lambda l: mm(B[(B.light == l) & (B.method == 'LR+CORAL')])),
         ('HGB + CORAL', lambda l: mm(B[(B.light == l) & (B.method == 'HGB+CORAL')])),
         ('LR + IW', lambda l: mm(B[(B.light == l) & (B.method == 'LR+IW')])),
         ('HGB + IW', lambda l: mm(B[(B.light == l) & (B.method == 'HGB+IW')])),
         ('LR, SWN', lambda l: mm(RV[(RV.exp == 'swn') & (RV.light == l) & (RV.fs == 'SWN') & (RV.model == 'LR') & (RV.setting == 'lodo')])),
         ('HGB, SWN', lambda l: mm(RV[(RV.exp == 'swn') & (RV.light == l) & (RV.fs == 'SWN') & (RV.model == 'HGB') & (RV.setting == 'lodo')])),
         ('LR, SWN+DYN', lambda l: mm(RV[(RV.exp == 'swn') & (RV.light == l) & (RV.fs == 'SWN+DYN') & (RV.model == 'LR') & (RV.setting == 'lodo')])),
         ('HGB, SWN+DYN', lambda l: mm(RV[(RV.exp == 'swn') & (RV.light == l) & (RV.fs == 'SWN+DYN') & (RV.model == 'HGB') & (RV.setting == 'lodo')])),
         ('CNN-LSTM, within (reference)', lambda l: mm(B[(B.light == l) & (B.method == 'CNN-LSTM') & (B.setting == 'within')]))]
rows = []
for lab, f in items:
    a = f(False); b = f(True); rows.append([lab, f3(a.auc), f3(a.f1), f3(b.auc), f3(b.f1)]); n('t7_' + lab, [f3(a.auc), f3(a.f1), f3(b.auc), f3(b.f1)])
J['tables']['t7'] = rows
hp = TU[(TU.fs == 'ALL') & (TU.model == 'LR')].hp.value_counts().to_dict(); n('lr_tuned_C', hp)

# ---------------------------------------------------------------- Table 8 significance (with dataset-level columns)
rows = []
for light in ([False, True] if G is not None else []):
    for _, g in G[G.light == light].iterrows():
        rows.append(['with L' if light else 'no L', g.metric, f'{g.A} − {g.B}', f"{g['diff']:+.3f}".replace('-', '−'), f'[{g.lo:+.3f}, {g.hi:+.3f}]'.replace('-', '−'), pf(g.p_holm),
                     f'{int(g.n_pos)}/{int(g.n_targets)}', f'[{g.h_lo:+.3f}, {g.h_hi:+.3f}]'.replace('-', '−'), f'{g.p_signflip:.3f}'])
        n(f"sig_{'L' if light else ''}{g.A}|{g.B}", dict(d=f"{g['diff']:+.3f}", lo=f'{g.lo:+.3f}', hi=f'{g.hi:+.3f}', p=pf(g.p), ph=pf(g.p_holm), npos=int(g.n_pos), nt=int(g.n_targets),
                                                       hlo=f'{g.h_lo:+.3f}', hhi=f'{g.h_hi:+.3f}', psf=f'{g.p_signflip:.3f}', per=g.per_target))
J['tables']['t8'] = rows
n('min_signflip_p', {5: f'{2/32:.4f}', 4: f'{2/16:.3f}'})

# ---------------------------------------------------------------- Table 9 decomposition
rows9 = []
for (l, fs, m, t), g in T.groupby(['light', 'fs', 'model', 'tgt']):
    w = g[g.setting == 'within'].iloc[0]; o = g[g.setting == 'lodo'].iloc[0]
    rows9.append(dict(light=l, fs=fs, m=m, tgt=t, op=o.f1_oracle - o.f1_05, rank=w.f1_oracle - o.f1_oracle))
D = pd.DataFrame(rows9); D['opl'] = D.op > D['rank']; rows = []
for t in ORDER:
    g = D[D.tgt == t]; rows.append([t, str(len(g)), str(int(g.opl.sum())), f3(g.op.median()), f3(g['rank'].median())])
rows.append(['All', str(len(D)), str(int(D.opl.sum())), f3(D.op.median()), f3(D['rank'].median())])
J['tables']['t9'] = rows; n('decomp', dict(n=len(D), opl=int(D.opl.sum()), op=f3(D.op.median()), rank=f3(D['rank'].median())))
pp = M[(~M.light) & (M.setting == 'lodo') & (M.fs == 'ALL')].groupby(['model', 'tgt'])[['prev', 'pred_pos']].mean()
n('predpos', {f'{m}_{t}': [f'{100*v.prev:.0f}', f'{100*v.pred_pos:.0f}'] for (m, t), v in pp.iterrows()})

# ---------------------------------------------------------------- Table 10 operating points (+ commissioning)
LS = RV[RV.exp == 'labelshift']; rows = []
for light in [False, True]:
    for m in ['LR', 'HGB']:
        r = T[(T.light == light) & (T.fs == 'ALL') & (T.model == m)]; w = r[r.setting == 'within']; o = r[r.setting == 'lodo']; ls = LS[(LS.light == light) & (LS.model == m)]
        c = CM[(CM.light == light) & (CM.model == m) & (CM.origin == 'standard')]
        vals = [w.f1_05.mean(), w.f1_oracle.mean(), o.f1_05.mean(), ls.f1_em.mean(), ls.f1_bbse.mean(), o.f1_prior.mean(), o.f1_day1.mean(),
                c['f1_pre-day'].mean(), c['f1_daily'].mean(), o.f1_oracle.mean()]
        rows.append(['with L' if light else 'no L', m] + [f3(v) for v in vals]); n(f"t10_{'L' if light else ''}{m}", [f3(v) for v in vals])
J['tables']['t10'] = rows
cases = []
for _, x in T[T.setting == 'lodo'].iterrows():
    if x.f1_oracle - x.f1_05 > 0.01: cases.append(dict(rec=(x.f1_day1 - x.f1_05) / (x.f1_oracle - x.f1_05), worse=x.f1_day1 < x.f1_05 - 1e-9))
C = pd.DataFrame(cases); n('day1_cases', dict(n=len(C), med=f'{100*C.rec.median():.0f}', q1=f'{100*C.rec.quantile(.25):.0f}', q3=f'{100*C.rec.quantile(.75):.0f}', worse=int(C.worse.sum())))
ls = LS.copy(); n('em_err', f2((ls.pi_em - ls.prev_train).abs().median())); n('bb_err', f2((ls.pi_bbse - ls.prev_train).abs().median()))
n('bb_clip', [int(((ls.pi_bbse <= 0.0101) | (ls.pi_bbse >= 0.9899)).sum()), len(ls)])
n('emcal', {f"{'L' if l else ''}{m}": f3(g.f1_em_cal.mean()) for (l, m), g in E2.groupby(['light', 'model'])}); n('emcal_err', f2((E2.pi_em_cal - E2.prev_train).abs().median()))

# ---------------------------------------------------------------- NEW Table: commissioning (standard split per target + rolling origins)
rows = []
for light in [False, True]:
    for m in ['LR', 'HGB']:
        for t in [x for x in ORDER if x in CM[CM.light == light].tgt.unique()]:
            g = CM[(CM.light == light) & (CM.model == m) & (CM.tgt == t)]
            s = g[g.origin == 'standard'].iloc[0]; ro = g[g.origin != 'standard']
            def cell(col): return f3(s[col]) + (f' ({ro[col].mean():.3f})' if len(ro) else '')
            rows.append(['with L' if light else 'no L', m, t, str(int(s.test_days)), cell('f1_0.5'), cell('f1_pre-day'), cell('f1_daily'), cell('f1_oracle')])
J['tables']['tc'] = rows
c = CM.copy(); c['d_pre'] = c['f1_pre-day'] - c['f1_0.5']; c['d_daily'] = c['f1_daily'] - c['f1_0.5']; c['d_dp'] = c['f1_daily'] - c['f1_pre-day']
n('commis', dict(cases=len(c), pre_better=int((c.d_pre > 1e-9).sum()), pre_worse=int((c.d_pre < -1e-9).sum()), daily_better=int((c.d_daily > 1e-9).sum()),
                 daily_worse=int((c.d_daily < -1e-9).sum()), daily_vs_pre_better=int((c.d_dp > 1e-9).sum()), med_pre=f3(c.d_pre.median()), med_daily=f3(c.d_daily.median()),
                 fallback=int(c.rooms_without_labelled_day.sum())))
st = CM[CM.origin == 'standard']
n('commis_mean', {f"{'L' if l else ''}{m}": [f3(g['f1_0.5'].mean()), f3(g['f1_pre-day'].mean()), f3(g['f1_daily'].mean()), f3(g['f1_oracle'].mean())] for (l, m), g in st.groupby(['light', 'model'])})
worst = c.sort_values('d_daily').iloc[0]; n('commis_worst', [worst.tgt, worst.model, bool(worst.light), str(worst.origin), f3(worst['f1_0.5']), f3(worst['f1_daily'])])

# ---------------------------------------------------------------- NEW Table: hierarchy (matched volume)
LV = ['same room', 'other rooms, same building', 'other buildings, same dataset', 'other datasets']
h = HI.groupby(['model', 'building', 'volume', 'level'])[['auc', 'f1', 'ntrain']].mean()
rows = []
for b in ['AAL', 'ROBOD', 'DK-APT']:
    nroom = HI[(HI.building == b)].room.nunique()
    for m in ['LR', 'HGB']:
        r = [b + f' ({nroom})' if m == 'LR' else '', m]
        for l in LV:
            if (m, b, 'matched', l) in h.index:
                v = h.loc[(m, b, 'matched', l)]; vf = h.loc[(m, b, 'full', l)]
                r.append(f'{v.auc:.3f} ({vf.auc:.3f})')
            else: r.append('–')
        r.append(f"{int(h.loc[(m, b, 'matched', 'same room')].ntrain):,}")
        rows.append(r)
        for l in LV:
            if (m, b, 'matched', l) in h.index:
                n(f'hier_{m}_{b}_{l}', [f3(h.loc[(m, b, "matched", l)].auc), f3(h.loc[(m, b, "full", l)].auc), f3(h.loc[(m, b, "matched", l)].f1)])
J['tables']['th'] = rows
n('hier_rooms', {b: int(HI[HI.building == b].room.nunique()) for b in ['AAL', 'ROBOD', 'DK-APT']})
n('hier_ntrain_full', {f'{b}_{l}': int(h.loc[('LR', b, 'full', l)].ntrain) for b in ['AAL', 'ROBOD', 'DK-APT'] for l in LV if ('LR', b, 'full', l) in h.index})
# DK-APT by room type: same-apartment vs other-apartment for kitchens etc. (room ids only)
# ---------------------------------------------------------------- shift effect
sh = SH.groupby(['version', 'light', 'fs', 'model', 'setting', 'tgt']).auc.mean()
n('shift_robod', {f"{v}_{'L' if l else ''}{fs}_{m}_{s}": f3(sh[(v, l, fs, m, s, 'ROBOD')]) for v in ['as released', 'corrected'] for l in [False, True] for fs in ['RAW', 'ALL'] for m in ['LR', 'HGB'] for s in ['within', 'lodo']})
shm = SH.groupby(['version', 'light', 'fs', 'model', 'setting', 'tgt']).auc.mean().groupby(['version', 'light', 'fs', 'model', 'setting']).mean()
n('shift_mean', {f"{v}_{'L' if l else ''}{fs}_{m}_{s}": f3(x) for (v, l, fs, m, s), x in shm.items()})

# ---------------------------------------------------------------- label rule, exclusions, budget
ru = RU.groupby(['light', 'model', 'setting', 'rule']).auc.mean().unstack('rule'); n('rule_maxd', f3((ru['any'] - ru['majority']).abs().max()))
ru2 = RU[RU.setting == 'lodo'].groupby(['light', 'model', 'rule', 'tgt']).auc.mean().unstack('rule'); n('rule_maxdt', f3((ru2['any'] - ru2['majority']).abs().max()))
x = M[(M.fs == 'ALL') & (~M.light) & (M.tgt != 'UCI-ROE')].groupby(['model', 'setting', 'tgt']).auc.mean().groupby(['model', 'setting']).mean()
n('excl_roe', {f'{m}_{s}': f3(v) for (m, s), v in x.items()})
fw_ = H[(H.exp == 'fewshot') & (H.fs == 'ALL') & (H.k <= 5)].groupby(['model', 'mode', 'k'])[['auc', 'f1']].mean()
n('few', {f'{m}_{mo}_{int(k)}': [f3(v.auc), f3(v.f1)] for (m, mo, k), v in fw_.iterrows()})
BW = RV[RV.exp == 'budget_w'].groupby(['model', 'k', 'share'])[['auc', 'f1']].mean()
n('budget_w', {f'{m}_{int(k)}_{sh}': [f3(v.auc), f3(v.f1)] for (m, k, sh), v in BW.iterrows()})
# pairwise
r = M[(~M.light) & (M.fs == 'ALL') & (M.model == 'LR')]
P = r[r.setting == 'pair'].pivot_table(index='src', columns='tgt', values='auc').reindex(index=ORDER, columns=ORDER)
for t in ORDER: P.loc[t, t] = r[(r.setting == 'within') & (r.tgt == t)].auc.mean()
P.loc['LODO'] = [r[(r.setting == 'lodo') & (r.tgt == t)].auc.mean() for t in ORDER]
off = P.iloc[:5].values.copy(); np.fill_diagonal(off, np.nan)
n('pair', dict(diag=f2(np.mean(np.diag(P.iloc[:5].values))), mean=f2(np.nanmean(off)), min=f2(np.nanmin(off)), max=f2(np.nanmax(off)),
               M={f'{s}>{t}': f2(P.loc[s, t]) for s in ORDER + ['LODO'] for t in ORDER}))
cue = M[(M.setting == 'lodo') & (M.model == 'LR')].groupby(['light', 'fs', 'tgt']).auc.mean()
n('cues', {f"{'L' if l else ''}{fs}_{t}": f2(v) for (l, fs, t), v in cue.items()})

# ---------------------------------------------------------------- figures
fig, ax = plt.subplots(figsize=(3.45, 2.5))
im = ax.imshow(P.values, cmap='viridis', vmin=0.4, vmax=1.0)
for i in range(P.shape[0]):
    for j in range(P.shape[1]):
        v = P.values[i, j]; ax.text(j, i, f'{v:.2f}', ha='center', va='center', fontsize=6.3, color='white' if v < 0.75 else 'black', fontweight='bold' if (i < 5 and i == j) else 'normal')
ax.add_patch(plt.Rectangle((-0.5, 4.5), 5, 1, fill=False, lw=1.0, ec='red'))
ax.set_xticks(range(5)); ax.set_xticklabels(ORDER, fontsize=6.3, rotation=30, ha='right'); ax.set_yticks(range(6)); ax.set_yticklabels(ORDER + ['LODO'], fontsize=6.3)
ax.set_xlabel('Test (target) dataset'); ax.set_ylabel('Training (source)')
cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02); cb.ax.tick_params(labelsize=6); cb.set_label('AUROC', fontsize=6.5)
fig.savefig(O + '/fig/fig_pair.png', dpi=300, bbox_inches='tight'); plt.close(fig)

fig, axs = plt.subplots(1, 2, figsize=(7.1, 2.15), gridspec_kw={'width_ratios': [5, 4]}, layout='constrained')
for ax, light in zip(axs, [False, True]):
    r = M[(M.light == light) & (M.setting == 'lodo') & (M.model == 'LR')]; tg = [t for t in ORDER if t in r.tgt.unique()]
    Pm = r.groupby(['fs', 'tgt']).auc.mean().unstack()[tg].reindex(FSO)
    im = ax.imshow(Pm.values, cmap='cividis', vmin=0.1, vmax=1.0, aspect='auto')
    for i in range(Pm.shape[0]):
        for j in range(Pm.shape[1]):
            v = Pm.values[i, j]; ax.text(j, i, f'{v:.2f}', ha='center', va='center', fontsize=6.3, color='white' if v < 0.6 else 'black', fontweight='bold' if v < 0.5 else 'normal')
            if v < 0.5: ax.add_patch(plt.Rectangle((j - 0.5, i - 0.5), 1, 1, fill=False, ec='#d62728', lw=1.2))
    ax.set_xticks(range(len(tg))); ax.set_xticklabels(tg, fontsize=6.5); ax.set_yticks(range(len(FSO))); ax.set_yticklabels(FSO if not light else [], fontsize=6.5)
    ax.set_title('T + CO$_2$ (5 datasets)' if not light else 'T + CO$_2$ + illuminance (4 datasets)', fontsize=7)
    for s_ in ax.spines.values(): s_.set_visible(False)
cb = fig.colorbar(im, ax=axs, fraction=0.025, pad=0.01); cb.set_label('LODO AUROC', fontsize=6.5); cb.ax.tick_params(labelsize=6)
fig.savefig(O + '/fig/fig_cues.png', dpi=300, bbox_inches='tight'); plt.close(fig)
n('cues_below05', int((M[(M.setting == 'lodo') & (M.model == 'LR')].groupby(['light', 'fs', 'tgt']).auc.mean() < 0.5).sum()))

# hierarchy figure: matched volume bars, full volume as markers
cols = {'same room': '#1f3b73', 'other rooms, same building': '#5b7aa6', 'other buildings, same dataset': '#9bb3d4', 'other datasets': '#c0504d'}
fig, axs = plt.subplots(1, 2, figsize=(7.1, 2.2), sharey=True)
for ax, m in zip(axs, ['LR', 'HGB']):
    x0 = 0; ticks = []; labs = []
    for b in ['AAL', 'ROBOD', 'DK-APT']:
        lv = [l for l in LV if (m, b, 'matched', l) in h.index]; wdt = 0.8 / len(lv)
        for i, l in enumerate(lv):
            v = h.loc[(m, b, 'matched', l)].auc; vf = h.loc[(m, b, 'full', l)].auc
            ax.bar(x0 + i * wdt, v, wdt * 0.95, color=cols[l], label=l if (b == 'DK-APT' and m == 'LR') else None)
            ax.plot(x0 + i * wdt, vf, marker='_', color='k', ms=7, mew=1.0)
            ax.text(x0 + i * wdt, v + 0.012, f'{v:.2f}', ha='center', fontsize=5.3)
        ticks.append(x0 + wdt * (len(lv) - 1) / 2); labs.append(f'{b}\n({HI[HI.building == b].room.nunique()} rooms)'); x0 += 1.15
    ax.set_xticks(ticks); ax.set_xticklabels(labs, fontsize=6.3); ax.set_title(m, fontsize=7.5); ax.set_ylim(0.4, 1.0); ax.spines[['top', 'right']].set_visible(False)
axs[0].set_ylabel('AUROC (matched training volume)')
axs[0].legend(fontsize=5.8, frameon=False, loc='lower center', bbox_to_anchor=(1.05, 1.08), ncol=4, handlelength=1)
fig.savefig(O + '/fig/fig_hier.png', dpi=300, bbox_inches='tight'); plt.close(fig)

f = H[(H.exp == 'fewshot') & (H.fs == 'ALL') & (H.k <= 5)]
fig, axs = plt.subplots(1, 2, figsize=(3.45, 1.75), sharex=True)
for ax, met, ttl in zip(axs, ['auc', 'f1'], ['AUROC', 'F1 at 0.5']):
    for m, ls_ in [('LR', '-'), ('HGB', '--')]:
        for mode, c_ in [('sources+target', '#1f3b73'), ('target only', '#c0504d')]:
            g = f[(f.model == m) & (f['mode'] == mode)].groupby('k')[met].mean()
            if mode == 'target only': g = g.drop(0, errors='ignore')
            if g.empty: continue
            ax.plot(g.index, g.values, ls=ls_, marker='o', ms=2.5, lw=1, color=c_, label=f'{m}, {mode}')
        wc = M[(~M.light) & (M.setting == 'within') & (M.fs == 'ALL') & (M.model == m)].groupby('tgt')[met].mean().mean()
        ax.axhline(wc, color='grey', lw=0.6, ls=ls_)
    ax.set_title(ttl, fontsize=7); ax.set_xlabel('Labeled target days $k$'); ax.spines[['top', 'right']].set_visible(False)
axs[0].legend(fontsize=5.3, frameon=False, loc='lower center', bbox_to_anchor=(1.1, 1.1), ncol=2, handlelength=1.8)
fig.savefig(O + '/fig/fig_few.png', dpi=300, bbox_inches='tight'); plt.close(fig)

json.dump(J, open(O + '/mdpi_numbers.json', 'w'), indent=1, default=str)
print('ok', len(J['n']), 'numbers', list(J['tables']))
