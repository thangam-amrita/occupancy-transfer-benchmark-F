"""Harmonise the five public datasets to one 15-min schema (T, CO2, Light, occ).

usage: python3 harmonise.py ROOT [majority|any] [noshift]

Label rule (identical for every dataset whose labels are finer than 15 min):
  majority : an interval is occupied if at least half of its labelled samples are occupied
  any      : an interval is occupied if any labelled sample is occupied
An interval is kept only if at least half of its expected label samples are present
(DK-APT is natively at 15 min and is used as published).

Revision 1 changes (see article, Section 3.1-3.2):
  * AAL is built from the official 5-min file (Zenodo 10.5281/zenodo.10673763) by averaging
    the three 5-min samples of each interval; intervals without camera counts are dropped
    (they are recording gaps, not empty rooms).
  * ROBOD uses all five rooms of the official release (github.com/ideas-lab-nus/robod).
    The indoor-environment stream (VOC, sound, RH, T, illuminance, PM2.5, CO2) is time-stamped
    8 h early in the release (UTC values labelled +08:00); it is shifted by +8 h before joining
    with occupancy (pass 'noshift' to reproduce the uncorrected alignment).
"""
import pandas as pd, numpy as np, sys
S = sys.argv[1]; R = S + '/occ/raw'; O = S + '/official'
RULE = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2] in ('majority', 'any') else 'majority'
SHIFT = 'noshift' not in sys.argv
out = []


def grid(df, room, bld, cols, occ, per15, freq='15min'):
    """df: one room, columns ts, sensors, occ (0/1, NaN = unlabelled); per15 = label samples per interval."""
    df = df.set_index('ts').sort_index()
    g = df[cols].resample(freq).mean()
    lab = df[occ].resample(freq)
    m, n = lab.mean(), lab.count()
    y = (m > 0) if RULE == 'any' else (m >= 0.5)
    g['occ'] = y.astype(float).where(n >= per15 / 2)
    g = g.dropna(subset=['occ', 'T', 'CO2'])
    g['building'] = bld; g['room'] = room
    return g.reset_index()


# 1 UCI Occupancy Detection (Mons, BE), 1 min
od = pd.concat([pd.read_csv(f'{S}/data/occdet/{f}') for f in ['datatraining.txt', 'datatest.txt', 'datatest2.txt']])
od['ts'] = pd.to_datetime(od.date); od = od.drop_duplicates('ts')
od = od.rename(columns={'Temperature': 'T', 'Light': 'Light', 'Humidity': 'RH'})
out.append(grid(od, 'OD-1', 'UCI-OD', ['T', 'CO2', 'Light'], 'Occupancy', 15))

# 2 UCI Room Occupancy Estimation (Hyderabad, IN), 30 s
ro = pd.read_csv(f'{S}/data/roomocc/Occupancy_Estimation.csv')
ro['ts'] = pd.to_datetime(ro.Date + ' ' + ro.Time, format='%Y/%m/%d %H:%M:%S')
ro['T'] = ro[[f'S{i}_Temp' for i in range(1, 5)]].mean(axis=1); ro['Light'] = ro[[f'S{i}_Light' for i in range(1, 5)]].mean(axis=1)
ro['CO2'] = ro.S5_CO2; ro['occ_'] = (ro.Room_Occupancy_Count > 0).astype(float)
out.append(grid(ro, 'ROE-1', 'UCI-ROE', ['T', 'CO2', 'Light'], 'occ_', 30))

# 3 Aalborg six offices (DK), official 5-min file, local wall time (Europe/Copenhagen)
aa = pd.read_csv(f'{O}/aal/dataset__2023_02_27__2023_12_31.csv', sep=';', low_memory=False)
aa = aa[aa.timestamp.notna()].copy()
utc = pd.to_datetime(aa.timestamp, utc=True)
for r in 'ABCDEF':
    g = pd.DataFrame({'ts': utc, 'T': aa[f'Room{r}:Sensor__room_temperature'].astype(float),
                      'CO2': aa[f'Room{r}:Sensor__CO2'].astype(float), 'Light': aa[f'Room{r}:Light__level__ceiling'].astype(float),
                      'occ_': (aa[f'Room{r}:People__amount'] >= 1).astype(float).where(aa[f'Room{r}:People__amount'].notna())})
    h = grid(g, 'AAL-' + r, 'AAL', ['T', 'CO2', 'Light'], 'occ_', 3)
    h['ts'] = h.ts.dt.tz_convert('Europe/Copenhagen').dt.tz_localize(None)   # local time for hour-of-day features
    out.append(h.drop_duplicates('ts', keep='first'))                       # DST fall-back hour (4 intervals)

# 4 ROBOD, five rooms (SG), 5 min
IEQ = ['voc', 'sound_pressure_level', 'indoor_relative_humidity', 'air_temperature', 'illuminance', 'pm2.5', 'indoor_co2']
RTYPE = {1: 'lecture', 2: 'lecture', 3: 'office', 4: 'office', 5: 'library'}
for k in range(1, 6):
    rb = pd.read_csv(f'{O}/robod/combined_Room{k}.csv'); rb['ts'] = pd.to_datetime(rb.timestamp.str[:16])
    ieq = rb[['ts'] + IEQ].copy()
    if SHIFT: ieq['ts'] = ieq.ts + pd.Timedelta('8h')
    g = rb[['ts', 'occupant_presence']].merge(ieq, on='ts', how='inner')
    g = g.rename(columns={'air_temperature': 'T', 'indoor_co2': 'CO2', 'illuminance': 'Light'})
    out.append(grid(g, f'ROBOD-{k}', 'ROBOD', ['T', 'CO2', 'Light'], 'occupant_presence', 3))

# 5 Danish apartments (residential), 15 min, logbook labels as published
dk = pd.read_csv(f'{R}/dk_apartments.csv', encoding='utf-8-sig'); dk['ts'] = pd.to_datetime(dk.datetime, format='%d-%m-%y %H:%M')
dk = dk.rename(columns={'indoor_operative_temperature': 'T', 'indoor_co2_concentration': 'CO2'})
dk['Light'] = np.nan
for (ap, rm), g in dk.groupby(['apartment_number', 'room_number']):
    out.append(grid(g, f'APT-{ap}-{rm}', 'DK-APT', ['T', 'CO2', 'Light'], 'occupancy_ground_truth', 1))

H = pd.concat(out, ignore_index=True)
suf = ('' if RULE == 'majority' else '_any') + ('' if SHIFT else '_noshift')
H.to_pickle(f'{S}/occ/harmonised15{suf}.pkl')
s = H.groupby('building').agg(rooms=('room', 'nunique'), rows=('occ', 'size'), occ=('occ', 'mean'), start=('ts', 'min'), end=('ts', 'max'),
                              days=('ts', lambda t: t.dt.normalize().nunique()), T=('T', 'median'), CO2=('CO2', 'median'), Light=('Light', 'median'))
print(RULE, 'shift' if SHIFT else 'noshift'); print(s.to_string()); print('total', len(H), H.room.nunique())
