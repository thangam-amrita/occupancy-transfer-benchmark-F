"""Hyperparameter tuning by leave-one-SOURCE-building-out validation (target never used), then LOBO test."""
import sys,time,itertools,numpy as np,pandas as pd; 
from common import *
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier

GRID={'LR':[dict(C=c) for c in [0.01,0.1,1,10]],
      'HGB':[dict(max_iter=it,learning_rate=lr,max_depth=d,min_samples_leaf=40) for it,lr,d in [(100,0.1,3),(300,0.05,None),(300,0.05,3),(600,0.03,6)]],
      'RF':[dict(n_estimators=200,min_samples_leaf=l,max_features=mf) for l,mf in [(5,'sqrt'),(20,'sqrt'),(50,0.5)]]}
def mk(mn,hp,seed=0,n=10**9):
    from sklearn.pipeline import make_pipeline; from sklearn.impute import SimpleImputer; from sklearn.preprocessing import StandardScaler
    if mn=='LR': return make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),LogisticRegression(max_iter=3000,**hp))
    if mn=='RF': return make_pipeline(SimpleImputer(strategy='median'),RandomForestClassifier(max_samples=0.5,n_jobs=2,random_state=seed,**hp))
    h=dict(hp); h['min_samples_leaf']=int(max(5,min(h['min_samples_leaf'],n//20))); return HistGradientBoostingClassifier(l2_regularization=1.0,random_state=seed,**h)
def fitp(mn,hp,cols,tr,te):
    m=mk(mn,hp,0,len(tr)); w=weights(tr)
    kw={'logisticregression__sample_weight':w} if mn=='LR' else ({'randomforestclassifier__sample_weight':w} if mn=='RF' else {'sample_weight':w})
    m.fit(tr[cols].values,tr.occ.values.astype(int),**kw); return m.predict_proba(te[cols].values)[:,1]
