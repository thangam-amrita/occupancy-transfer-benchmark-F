"""EM prior correction on CALIBRATED posteriors (Platt scaling fitted on leave-one-source-out predictions)."""
import sys,numpy as np,pandas as pd; S=sys.argv[1]; sys.path.insert(0,S+'/occ/scripts')
from common import *
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
F=pd.read_pickle(S+'/occ/features.pkl').reset_index(drop=True); R=[]
lg=lambda p: np.log(np.clip(p,1e-6,1-1e-6)/(1-np.clip(p,1e-6,1-1e-6)))
def em(p,pi_s):
    pi=pi_s
    for _ in range(500):
        a=pi/pi_s*p; b=(1-pi)/(1-pi_s)*(1-p); new=(a/(a+b)).mean()
        if abs(new-pi)<1e-7: break
        pi=new
    return float(np.clip(pi,0.01,0.99))
for light in [False,True]:
    doms=DOMS if not light else [d for d in DOMS if d!='DK-APT']; D=F[F.building.isin(doms)]; cols=fsets(light)['ALL']; trA=D[D.split=='train']
    for mn in ['LR','HGB']:
        for tgt in doms:
            te=D[(D.building==tgt)&(D.split=='test')]; tu=D[(D.building==tgt)&(D.split=='train')]; src=trA[trA.building!=tgt]
            # leave-one-source-out predictions for calibration
            ps=[];ys=[];ws=[]
            for v in [d for d in doms if d!=tgt]:
                pv,_=fit_predict(mn,cols,src[src.building!=v],src[src.building==v],0); ps.append(pv); ys.append(src[src.building==v].occ.values); ws.append(np.full(len(pv),1.0/len(pv)))
            ps=np.concatenate(ps); ys=np.concatenate(ys); ws=np.concatenate(ws)
            cal=LogisticRegression(C=1e6).fit(lg(ps)[:,None],ys,sample_weight=ws*len(ws))
            pi_s=float((ws*ys).sum()/ws.sum())
            p,m=fit_predict(mn,cols,src,te,0); pu=m.predict_proba(tu[cols].values)[:,1]
            cu=cal.predict_proba(lg(pu)[:,None])[:,1]; ce=cal.predict_proba(lg(p)[:,None])[:,1]
            pi=em(cu,pi_s); a=pi/pi_s*ce; b=(1-pi)/(1-pi_s)*(1-ce); adj=a/(a+b)
            y=te.occ.values.astype(int)
            R.append(dict(light=light,model=mn,tgt=tgt,prev_train=tu.occ.mean(),prev_test=y.mean(),pi_s_cal=pi_s,pi_em_cal=pi,
                          f1_05=f1_score(y,(p>=.5).astype(int)),f1_cal=f1_score(y,(ce>=.5).astype(int)),f1_em_cal=f1_score(y,(adj>=.5).astype(int))))
        print(light,mn,flush=True)
pd.DataFrame(R).to_csv(S+'/occ/res_em2.csv',index=False); print('done')
