import sys,pandas as pd; sys.path.insert(0,sys.argv[1]+'/occ/scripts')
from feats import build,zfit
SUF=sys.argv[2] if len(sys.argv)>2 else ''
H=pd.read_pickle(sys.argv[1]+f'/occ/harmonised15{SUF}.pkl')
F=build(H); F=zfit(F,['T','CO2','Light','d_T','d_CO2','d_Light'])
F.to_pickle(sys.argv[1]+f'/occ/features{SUF}.pkl')
print(F.groupby(['building','split']).agg(n=('occ','size'),occ=('occ','mean')).round(3).to_string())
print(F.isna().mean().round(3)[F.isna().mean()>0].to_dict())
