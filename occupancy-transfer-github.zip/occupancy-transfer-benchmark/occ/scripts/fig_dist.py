import sys,numpy as np,pandas as pd,matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
S=sys.argv[1]; F=pd.read_pickle(S+'/occ/features.pkl')
plt.rcParams.update({'font.family':'serif','font.size':7.5,'axes.linewidth':0.6,'pdf.fonttype':42})
order=['UCI-OD','UCI-ROE','AAL','ROBOD','DK-APT']
fig,axs=plt.subplots(2,1,figsize=(3.45,3.3),sharex=True)
for ax,var,lab,lg in [(axs[0],'CO2','CO$_2$ (ppm)',False),(axs[1],'Light','Illuminance (lux)',True)]:
    pos=[];data=[];cols=[]
    for i,b in enumerate(order):
        for j,o in enumerate([0,1]):
            v=F[(F.building==b)&(F.occ==o)][var].dropna().values
            if lg: v=np.log10(v+1)
            data.append(v if len(v) else [np.nan]); pos.append(i*3+j); cols.append(['#9aa5b1','#c0504d'][j])
    bp=ax.boxplot(data,positions=pos,widths=0.8,showfliers=False,patch_artist=True,medianprops=dict(color='k',lw=0.8),whiskerprops=dict(lw=0.6),capprops=dict(lw=0.6),boxprops=dict(lw=0.6))
    for p,c in zip(bp['boxes'],cols): p.set_facecolor(c)
    ax.set_ylabel(lab); ax.spines[['top','right']].set_visible(False)
    if lg: ax.set_yticks([0,np.log10(11),np.log10(101),np.log10(1001)]); ax.set_yticklabels(['0','10','100','1000']); ax.set_ylabel('Illuminance (lux, log$_{10}$(1+x) scale)')
axs[1].text(4*3+0.5,0.3,'not\nrecorded',ha='center',fontsize=6,color='grey')
axs[1].set_xticks([i*3+0.5 for i in range(5)]); axs[1].set_xticklabels(order)
axs[0].legend([plt.Rectangle((0,0),1,1,fc='#9aa5b1'),plt.Rectangle((0,0),1,1,fc='#c0504d')],['empty','occupied'],frameon=False,fontsize=6.5,ncol=2,loc='upper left')
import os; os.makedirs(S+'/apaper/fig',exist_ok=True)
fig.tight_layout(); fig.savefig(S+'/apaper/fig/fig_dist.pdf',bbox_inches='tight'); fig.savefig(S+'/apaper/fig/fig_dist.png',dpi=300,bbox_inches='tight'); print('ok')
