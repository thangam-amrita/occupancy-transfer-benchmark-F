import sys,json,numpy as np,pandas as pd; S=sys.argv[1]; sys.path.insert(0,S+'/occ/scripts')
from common import *
from sklearn.metrics import f1_score, matthews_corrcoef
F=pd.read_pickle(S+'/occ/features.pkl').reset_index(drop=True); R=[]; B=[]
rng=np.random.default_rng(0); DROP=[0]
def boot(te,p,thr,nb=1000):
    days=te.day.values; ud=np.unique(days); idx={d:np.where(days==d)[0] for d in ud}; y=te.occ.values.astype(int); out=[]
    for _ in range(nb):
        s=np.concatenate([idx[d] for d in rng.choice(ud,len(ud))])
        if len(np.unique(y[s]))<2: DROP[0]+=1; continue
        out.append((roc_auc_score(y[s],p[s]), f1_score(y[s],(p[s]>=thr).astype(int),zero_division=0)))
    a=np.array(out); return np.percentile(a,[2.5,97.5],axis=0)
for light in [False,True]:
    doms=DOMS if not light else [d for d in DOMS if d!='DK-APT']; D=F[F.building.isin(doms)]
    FS=fsets(light)
    for fs in ['RAW','RAW+TIME','ALL']:
        cols=FS[fs]
        for mn in ['LR','HGB']:
            for tgt in doms:
                te=D[(D.building==tgt)&(D.split=='test')]; trt=D[(D.building==tgt)&(D.split=='train')]
                for setting in ['within','lodo']:
                    tr=D[(D.split=='train')&((D.building==tgt) if setting=='within' else (D.building!=tgt))]
                    p,m=fit_predict(mn,cols,tr,te,0)
                    y=te.occ.values.astype(int)
                    res=dict(light=light,fs=fs,model=mn,tgt=tgt,setting=setting,auc=roc_auc_score(y,p),prev=y.mean())
                    res['f1_05']=f1_score(y,(p>=.5).astype(int),zero_division=0)
                    res['f1_oracle'],res['thr_oracle']=best_threshold(y,p)
                    DROP[0]=0; lo,hi=boot(te,p,0.5); res.update(boot_dropped=DROP[0],auc_lo=lo[0],auc_hi=hi[0],f1_lo=lo[1],f1_hi=hi[1])
                    if setting=='lodo':
                        # thresholds from ONE labelled target day (first day of the target's training period that has both classes)
                        days=sorted(trt.day.unique()); d1=next((d for d in days if trt[trt.day==d].occ.nunique()==2),None)
                        lab=trt[trt.day==d1]; pl=m.predict_proba(lab[cols].values)[:,1]
                        _,t1=best_threshold(lab.occ.values,pl)
                        # prior matching: threshold so that predicted rate on all unlabelled target-train rows equals the prevalence seen on that labelled day
                        pu=m.predict_proba(trt[cols].values)[:,1]; pri=lab.occ.mean(); t2=np.quantile(pu,1-pri)
                        res.update(f1_day1=f1_score(y,(p>=t1).astype(int),zero_division=0), f1_prior=f1_score(y,(p>=t2).astype(int),zero_division=0),
                                   thr_day1=t1, thr_prior=t2, prior_day1=pri)
                    R.append(res)
        print(light,fs,flush=True)
pd.DataFrame(R).to_csv(S+'/occ/res_thr.csv',index=False); print('done')
