"""Hyperparameter tuning by leave-one-SOURCE-building-out validation (target never used), then LOBO test."""
import sys,time,itertools,numpy as np,pandas as pd; S=sys.argv[1]; sys.path.insert(0,S+'/occ/scripts')
from common import *
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
F=pd.read_pickle(S+'/occ/features.pkl').reset_index(drop=True)
GRID={'LR':[dict(C=c) for c in [0.0001,0.001,0.01,0.1,1,10]],
      'HGB':[dict(max_iter=it,learning_rate=lr,max_depth=d,min_samples_leaf=40) for it,lr,d in [(100,0.1,2),(300,0.05,2),(100,0.1,3),(300,0.05,3),(600,0.03,6),(300,0.05,None)]],
      'RF':[dict(n_estimators=200,min_samples_leaf=l,max_features=mf) for l,mf in [(5,'sqrt'),(20,'sqrt'),(50,0.5)]]}
def mk(mn,hp,seed=0,n=10**9):
    from sklearn.pipeline import make_pipeline; from sklearn.impute import SimpleImputer; from sklearn.preprocessing import StandardScaler
    if mn=='LR': return make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),LogisticRegression(max_iter=3000,**hp))
    if mn=='RF': return make_pipeline(SimpleImputer(strategy='median'),RandomForestClassifier(max_samples=0.5,n_jobs=2,random_state=seed,**hp))
    h=dict(hp); h['min_samples_leaf']=int(max(5,min(h['min_samples_leaf'],n//20))); return HistGradientBoostingClassifier(l2_regularization=1.0,random_state=seed,**h)
def fitp(mn,hp,cols,tr,te):
    m=mk(mn,hp,0,len(tr)); w=weights(tr)
    kw={'logisticregression__sample_weight':w} if mn=='LR' else ({'randomforestclassifier__sample_weight':w} if mn=='RF' else {'sample_weight':w})
    m.fit(tr[cols].values,tr.occ.values.astype(int),**kw); return m.predict_proba(te[cols].values)[:,1]
R=[]; t0=time.time()
for light in [False,True]:
    doms=DOMS if not light else [d for d in DOMS if d!='DK-APT']; D=F[F.building.isin(doms)]; tr_all=D[D.split=='train']
    for fs in ['RAW','ALL']:
        cols=fsets(light)[fs]
        for mn in ['LR','HGB','RF']:
            for tgt in doms:
                srcs=[d for d in doms if d!=tgt]; te=D[(D.building==tgt)&(D.split=='test')]
                scores=[]
                for hp in GRID[mn]:
                    s=[]
                    for v in srcs:   # validate on held-out source building's training period
                        tr=tr_all[tr_all.building.isin([x for x in srcs if x!=v])]; va=tr_all[tr_all.building==v]
                        if va.occ.nunique()<2: continue
                        s.append(roc_auc_score(va.occ.values,fitp(mn,hp,cols,tr,va)))
                    scores.append(np.mean(s))
                best=GRID[mn][int(np.argmax(scores))]
                p=fitp(mn,best,cols,tr_all[tr_all.building.isin(srcs)],te)
                R.append(dict(light=light,fs=fs,model=mn,tgt=tgt,hp=str(best),val_auc=max(scores),**metrics(te.occ.values,p)))
            print(light,fs,mn,round(time.time()-t0),flush=True)
            pd.DataFrame(R).to_csv(S+'/occ/res_tune.csv',index=False)
print('done')
