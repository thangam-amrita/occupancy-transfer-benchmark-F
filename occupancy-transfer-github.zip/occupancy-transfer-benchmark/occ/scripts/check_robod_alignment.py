"""Time-alignment check of the official ROBOD release (revision 1, Section 3.1).
For every room, the lag (in 5-min steps, -12 h .. +12 h) that maximises the Pearson correlation between
  (a) indoor illuminance and outdoor global horizontal solar radiation (occupancy-independent check),
  (b) indoor relative humidity and outdoor relative humidity (occupancy-independent check),
  (c) illuminance, CO2, Wi-Fi devices and lighting energy and the occupant-presence label.
A positive lag means the first signal has to be moved LATER to line up with the second.
usage: python3 check_robod_alignment.py ROOT  -> occ/res_robod_alignment.csv"""
import sys, numpy as np, pandas as pd
S = sys.argv[1]; R = []
LAGS = range(-144, 145)
for k in range(1, 6):
    d = pd.read_csv(f'{S}/official/robod/combined_Room{k}.csv'); d['ts'] = pd.to_datetime(d.timestamp.str[:16]); d = d.set_index('ts')
    pairs = [('illuminance', 'global_horizontal_solar_radiation'), ('indoor_relative_humidity', 'outdoor_relative_humidity'),
             ('illuminance', 'occupant_presence'), ('indoor_co2', 'occupant_presence'), ('wifi_connected_devices', 'occupant_presence'),
             ('lighting_energy', 'occupant_presence')]
    for a, b in pairs:
        x = d[a].astype(float); y = d[b].astype(float)
        r = np.array([x.shift(l).corr(y) for l in LAGS]); i = int(np.nanargmax(r))
        R.append(dict(room=k, signal=a, reference=b, r_at_0=round(float(x.corr(y)), 3), best_lag_h=list(LAGS)[i] * 5 / 60, r_best=round(float(r[i]), 3)))
O = pd.DataFrame(R); O.to_csv(f'{S}/occ/res_robod_alignment.csv', index=False); print(O.to_string(index=False))
