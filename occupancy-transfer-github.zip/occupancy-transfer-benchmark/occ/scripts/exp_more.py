import sys,time,numpy as np,pandas as pd; S=sys.argv[1]; sys.path.insert(0,S+'/occ/scripts')
from common import *
F=pd.read_pickle(S+'/occ/features.pkl').reset_index(drop=True)
FS=fsets(False); R=[]; t0=time.time(); cols=FS['ALL']; tr=F[F.split=='train']
for mn in ['LR','HGB']:
    for b in ['AAL','DK-APT']:
        for r in sorted(F[F.building==b].room.unique()):
            te=F[(F.room==r)&(F.split=='test')]
            levels=[('same room',tr[tr.room==r]),('other rooms, same dataset',tr[(tr.building==b)&(tr.room!=r)]),('other buildings',tr[tr.building!=b])]
            if te.occ.nunique()<2 or any(d.occ.nunique()<2 for _,d in levels): continue   # paired: only rooms where all three levels are trainable
            for lvl,trd in levels:
                p,_=fit_predict(mn,cols,trd,te,0)
                R.append(dict(exp='hier',model=mn,fs='ALL',building=b,room=r,level=lvl,ntrain=len(trd),**metrics(te.occ.values,p)))
    print('hier',mn,round(time.time()-t0),flush=True)
for mn in ['LR','HGB']:
    for tgt in DOMS:
        te=F[(F.building==tgt)&(F.split=='test')]; trt=F[(F.building==tgt)&(F.split=='train')]
        days=sorted(trt.day.unique()); src=F[(F.building!=tgt)&(F.split=='train')]
        for k in [0,1,2,3,5]:
            lab=trt[trt.day.isin(days[:k])]
            if k>0 and lab.occ.nunique()<2: continue
            pool=pd.concat([src,lab]) if k>0 else src
            p,_=fit_predict(mn,cols,pool,te,0)
            R.append(dict(exp='fewshot',model=mn,fs='ALL',tgt=tgt,k=k,mode='sources+target',**metrics(te.occ.values,p)))
            if k>0:
                p,_=fit_predict(mn,cols,lab,te,0)
                R.append(dict(exp='fewshot',model=mn,fs='ALL',tgt=tgt,k=k,mode='target only',const=float(np.std(p)<1e-9),**metrics(te.occ.values,p)))
    print('few',mn,round(time.time()-t0),flush=True)
pd.DataFrame(R).to_csv(S+'/occ/res_more.csv',index=False); print('done',len(R))
