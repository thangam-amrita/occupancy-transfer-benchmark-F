import numpy as np, pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score, f1_score, matthews_corrcoef, balanced_accuracy_score
DOMS=['UCI-OD','UCI-ROE','AAL','ROBOD','DK-APT']
TIME=['hsin','hcos']   # weekend flag dropped: DK-APT test period is a weekend, all its training days are weekdays
def fsets(light):
    L=['Light'] if light else []
    def w(cols): return [c for c in cols if light or 'Light' not in c]
    return {
     'RAW': w(['T','CO2','Light']),
     'RAW+TIME': w(['T','CO2','Light'])+TIME,
     'DYN': w(['d_T','d_CO2','d_Light','h1_T','h1_CO2','h1_Light']),
     'REL': w(['rel_T','rel_CO2','rel_Light']),
     'ZNORM': w(['z_T','z_CO2','z_Light','z_d_T','z_d_CO2','z_d_Light']),
     'INV': w(['rel_T','rel_CO2','rel_Light','d_T','d_CO2','d_Light','h1_T','h1_CO2','h1_Light','z_T','z_CO2','z_Light']),
     'ALL': w(['T','CO2','Light','d_T','d_CO2','d_Light','h1_T','h1_CO2','h1_Light','rel_T','rel_CO2','rel_Light'])+TIME,
    }
def model(name,seed=0,n=10**9):
    if name=='LR': return make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),LogisticRegression(max_iter=2000,C=1.0))
    if name=='RF': return make_pipeline(SimpleImputer(strategy='median'),RandomForestClassifier(n_estimators=200,min_samples_leaf=5,max_samples=0.5,n_jobs=2,random_state=seed))
    if name=='HGB': return HistGradientBoostingClassifier(max_iter=300,learning_rate=0.05,min_samples_leaf=int(max(5,min(40,n//20))),l2_regularization=1.0,random_state=seed)
def weights(df):
    # every domain contributes equal total weight; within domain every room equal
    w=np.ones(len(df)); nd=df.building.nunique()
    for b,g in df.groupby('building'):
        nr=g.room.nunique()
        for r,gr in g.groupby('room'): w[df.index.get_indexer(gr.index)]=1.0/(nd*nr*len(gr))
    return w*len(df)
def metrics(y,p):
    yh=(p>=0.5).astype(int)
    auc=roc_auc_score(y,p) if len(np.unique(y))>1 else np.nan
    return dict(auc=auc,f1=f1_score(y,yh,zero_division=0),mcc=matthews_corrcoef(y,yh),bacc=balanced_accuracy_score(y,yh),prev=float(np.mean(y)),pred_pos=float(np.mean(yh)),n=int(len(y)))
def fit_predict(mname,cols,tr,te,seed=0):
    m=model(mname,seed,len(tr)); w=weights(tr)
    kw={'logisticregression__sample_weight':w} if mname=='LR' else ({'randomforestclassifier__sample_weight':w} if mname=='RF' else {'sample_weight':w})
    m.fit(tr[cols].values,tr.occ.values.astype(int),**kw)
    return m.predict_proba(te[cols].values)[:,1], m
from sklearn.metrics import precision_recall_curve
def best_threshold(y,p):
    """Exact F1-optimal threshold: every distinct score is a candidate; an interval is predicted occupied
    when its score is >= the threshold. Returns (max F1, threshold); ties -> the highest threshold."""
    y=np.asarray(y).astype(int); p=np.asarray(p,dtype=float)
    if y.sum()==0: return 0.0, np.inf
    pr,rc,th=precision_recall_curve(y,p)
    f=np.where(pr[:-1]+rc[:-1]>0, 2*pr[:-1]*rc[:-1]/np.maximum(pr[:-1]+rc[:-1],1e-12), 0.0)
    i=len(f)-1-np.argmax(f[::-1])
    return float(f[i]), float(th[i])
