"""Baselines requested for review: CNN-LSTM (source-only and DANN), CORAL and importance weighting.
Saves per-row test predictions for the significance tests."""
import sys,time,pickle,numpy as np,pandas as pd,torch,torch.nn as nn
S=sys.argv[1]; sys.path.insert(0,S+'/occ/scripts')
from common import *
from scipy.linalg import sqrtm
torch.set_num_threads(1)
F=pd.read_pickle(S+'/occ/features.pkl').sort_values(['room','ts']).reset_index(drop=True)
W=8  # 2 h of history
def windows(D,sens):
    """sequence of the last W intervals per row, never crossing a gap in the 15-min record
    (left-padded by repeating the first interval of the contiguous segment)"""
    X=np.zeros((len(D),W,len(sens)),dtype=np.float32)
    for r,g in D.groupby('room',sort=False):
        g=g.sort_values('ts'); v=g[sens].ffill().bfill().fillna(0).values.astype(np.float32)
        seg=(g.ts.diff()!=pd.Timedelta('15min')).cumsum().values; start=np.zeros(len(g),dtype=int)
        first={}
        for i,sg in enumerate(seg):
            first.setdefault(sg,i); start[i]=first[sg]
        idx=np.arange(len(v)); rows=D.index.get_indexer(g.index)
        for j in range(W):
            X[rows,W-1-j,:]=v[np.maximum(idx-j,start)]
    return X
class Net(nn.Module):
    def __init__(s,c,h=32):
        super().__init__(); s.conv=nn.Sequential(nn.Conv1d(c,h,3,padding=1),nn.ReLU()); s.lstm=nn.LSTM(h,h,batch_first=True)
        s.head=nn.Sequential(nn.Linear(h+2,32),nn.ReLU(),nn.Linear(32,1)); s.dom=nn.Sequential(nn.Linear(h+2,32),nn.ReLU(),nn.Linear(32,1))
    def feat(s,x,t):
        z=s.conv(x.transpose(1,2)).transpose(1,2); _,(hn,_)=s.lstm(z); return torch.cat([hn[-1],t],1)
    def forward(s,x,t): return s.head(s.feat(x,t)).squeeze(1)
class GRL(torch.autograd.Function):
    @staticmethod
    def forward(ctx,x,l): ctx.l=l; return x.view_as(x)
    @staticmethod
    def backward(ctx,g): return -ctx.l*g, None
def train_dl(Xs,Ts,ys,ws,seed,Xt=None,Tt=None,epochs=15,n_per=40000):
    torch.manual_seed(seed); np.random.seed(seed)
    mu=Xs.reshape(-1,Xs.shape[2]).mean(0); sd=Xs.reshape(-1,Xs.shape[2]).std(0)+1e-6
    net=Net(Xs.shape[2]); opt=torch.optim.Adam(net.parameters(),1e-3); bce=nn.BCEWithLogitsLoss()
    Xs_=torch.tensor((Xs-mu)/sd); Ts_=torch.tensor(Ts); ys_=torch.tensor(ys,dtype=torch.float32)
    p=ws/ws.sum(); nb=n_per//256
    if Xt is not None: Xt_=torch.tensor((Xt-mu)/sd); Tt_=torch.tensor(Tt)
    for ep in range(epochs):
        idx=np.random.choice(len(ys),nb*256,p=p)
        for b in range(nb):
            i=idx[b*256:(b+1)*256]; opt.zero_grad()
            f=net.feat(Xs_[i],Ts_[i]); loss=bce(net.head(f).squeeze(1),ys_[i])
            if Xt is not None:
                prog=(ep*nb+b)/(epochs*nb); lam=2/(1+np.exp(-10*prog))-1
                j=np.random.randint(0,len(Xt_),256); ft=net.feat(Xt_[j],Tt_[j])
                d=net.dom(GRL.apply(torch.cat([f,ft]),lam)).squeeze(1)
                loss=loss+bce(d,torch.cat([torch.zeros(256),torch.ones(256)]))
            loss.backward(); opt.step()
    net.eval(); return net,mu,sd
def pred_dl(m,X,T):
    net,mu,sd=m
    with torch.no_grad(): return torch.sigmoid(net(torch.tensor((X-mu)/sd),torch.tensor(T))).numpy()
def coral_fit_predict(mn,cols,tr,tu,te):
    from sklearn.impute import SimpleImputer
    imp=SimpleImputer(strategy='median').fit(tr[cols]); Xs=imp.transform(tr[cols]); Xu=imp.transform(tu[cols]); Xe=imp.transform(te[cols])
    Zs=np.zeros_like(Xs)
    for b in tr.building.unique():          # standardise each source domain separately
        k=(tr.building==b).values; Zs[k]=(Xs[k]-Xs[k].mean(0))/(Xs[k].std(0)+1e-9)
    mt,st=Xu.mean(0),Xu.std(0)+1e-9; Zu=(Xu-mt)/st; Ze=(Xe-mt)/st
    Cs=np.cov(Zs,rowvar=False)+np.eye(Zs.shape[1]); Ct=np.cov(Zu,rowvar=False)+np.eye(Zs.shape[1])
    A=np.real(np.linalg.inv(sqrtm(Cs))@sqrtm(Ct)); Za=Zs@A
    trc=tr.copy(); tec=te.copy(); cc=[f'c{i}' for i in range(len(cols))]
    trc[cc]=Za; tec[cc]=Ze
    return fit_predict(mn,cc,trc,tec,0)[0]
def iw_fit_predict(mn,cols,tr,tu,te):
    from sklearn.pipeline import make_pipeline; from sklearn.impute import SimpleImputer; from sklearn.preprocessing import StandardScaler; from sklearn.linear_model import LogisticRegression
    X=pd.concat([tr[cols],tu[cols]]); d=np.r_[np.zeros(len(tr)),np.ones(len(tu))]
    dc=make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),LogisticRegression(max_iter=2000)).fit(X,d,logisticregression__sample_weight=np.r_[np.full(len(tr),0.5/len(tr)),np.full(len(tu),0.5/len(tu))]*len(d))
    pt=dc.predict_proba(tr[cols])[:,1]; iw=np.clip(pt/(1-pt),0.1,10)
    m=model(mn,0,len(tr)); w=weights(tr)*iw; w=w/w.mean()
    kw={'logisticregression__sample_weight':w} if mn=='LR' else {'sample_weight':w}
    m.fit(tr[cols].values,tr.occ.values.astype(int),**kw); return m.predict_proba(te[cols].values)[:,1]
import os
PART=sys.argv[2] if len(sys.argv)>2 else 'both'
R=[]; P={}; t0=time.time()
if os.path.exists(S+'/occ/res_base.csv') and PART!='both':      # resume: keep finished (light, target) blocks
    R=pd.read_csv(S+'/occ/res_base.csv').to_dict('records'); P=pickle.load(open(S+'/occ/preds_base.pkl','rb'))
DONE={(r['light'],r['tgt']) for r in R if r['method']=='CNN-LSTM+DANN' and r['seed']==2}
for light in [l for l in [False,True] if PART=='both' or (PART=='light')==l]:
    doms=DOMS if not light else [d for d in DOMS if d!='DK-APT']; D=F[F.building.isin(doms)].reset_index(drop=True)
    sens=['T','CO2']+(['Light'] if light else []); cols=fsets(light)['ALL']
    X=windows(D,sens); TT=D[['hsin','hcos']].values.astype(np.float32); y=D.occ.values.astype(np.float32)
    for tgt in doms:
        if (light,tgt) in DONE: continue
        R=[r for r in R if not (r['light']==light and r['tgt']==tgt)]
        te=D[(D.building==tgt)&(D.split=='test')]; tu=D[(D.building==tgt)&(D.split=='train')]
        src=D[(D.building!=tgt)&(D.split=='train')]; ie=te.index.values; yt=te.occ.values
        def rec(method,setting,p,seed=0):
            R.append(dict(light=light,method=method,setting=setting,tgt=tgt,seed=seed,**metrics(yt,p))); P[(light,method,setting,tgt,seed)]=p
        # classical references (same rows) for paired tests
        rec('LR','within',fit_predict('LR',cols,tu,te,0)[0]); rec('LR','lodo',fit_predict('LR',cols,src,te,0)[0]); rec('HGB','lodo',fit_predict('HGB',cols,src,te,0)[0])
        for mn in ['LR','HGB']:
            rec(f'{mn}+CORAL','lodo',coral_fit_predict(mn,cols,src,tu,te)); rec(f'{mn}+IW','lodo',iw_fit_predict(mn,cols,src,tu,te))
        for seed in [0,1,2]:
            for setting,trd in [('within',tu),('lodo',src)]:
                m=train_dl(X[trd.index.values],TT[trd.index.values],y[trd.index.values],weights(trd),seed)
                rec('CNN-LSTM',setting,pred_dl(m,X[ie],TT[ie]),seed)
            m=train_dl(X[src.index.values],TT[src.index.values],y[src.index.values],weights(src),seed,X[tu.index.values],TT[tu.index.values])
            rec('CNN-LSTM+DANN','lodo',pred_dl(m,X[ie],TT[ie]),seed)
        print(light,tgt,round(time.time()-t0),flush=True)
        pd.DataFrame(R).to_csv(S+'/occ/res_base.csv',index=False); pickle.dump(P,open(S+'/occ/preds_base.pkl','wb'))
# keep test frame (day labels) for bootstrap

print('done')
